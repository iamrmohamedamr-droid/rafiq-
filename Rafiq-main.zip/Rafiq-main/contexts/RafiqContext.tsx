import { createContext, useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { Vibration } from 'react-native';
import { initialData, loadData, saveData, today, uid, type AppData, type Task, type Medication, type Note, type Profile, type ReferenceCard } from '@/services/storage';
import { captureDoses } from '@/services/progress';
import type { Mode } from '@/constants/config';
import { speakArabic, stopSpeech } from '@/services/localSpeech';
import { syncReminders } from '@/services/notifications';
type SaveStatus = 'loading' | 'saving' | 'saved' | 'error';
interface RafiqValue {
  data: AppData; ready: boolean; saveStatus: SaveStatus; notice: string; setNotice: (text: string) => void;
  setMode: (mode: Mode) => void; updatePreferences: (patch: Partial<AppData['preferences']>) => void;
  updateProfile: (profile: Profile) => void; addTask: (task: Omit<Task, 'id' | 'completed' | 'day'>, id?: string) => void;
  toggleTask: (id: string) => void; deleteTask: (id: string) => void;
  addMedication: (med: Omit<Medication, 'id' | 'taken'>, id?: string) => void; takeMedication: (id: string, time: string) => void; deleteMedication: (id: string) => void;
  addNote: (note: Omit<Note, 'id' | 'created'>) => void; deleteNote: (id: string) => void; addPhrase: (text: string) => void; deletePhrase: (id: string) => void;
  addReference: (card: Omit<ReferenceCard, 'id' | 'created'>) => void; deleteReference: (id: string) => void;
  restoreData: (next: AppData) => Promise<void>;
}
export const RafiqContext = createContext<RafiqValue | undefined>(undefined);
export function RafiqProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AppData>(initialData); const [ready, setReady] = useState(false);
  const [saveStatus, setSaveStatus] = useState<SaveStatus>('loading'); const [notice, setNotice] = useState('');
  const writable = useRef(false); const saveQueue = useRef(Promise.resolve()); const reminderQueue = useRef(Promise.resolve()); const announced = useRef(new Set<string>());
  useEffect(() => { let active = true; loadData().then(saved => { if (active) { writable.current = true; setData(saved); setReady(true); setSaveStatus('saved'); } }).catch(() => { if (active) { setReady(true); setSaveStatus('error'); setNotice('تعذّر قراءة البيانات المحلية. أعد فتح التطبيق قبل إجراء تعديلات.'); } }); return () => { active = false; void stopSpeech(); }; }, []);
  useEffect(() => {
    if (!ready || !writable.current) return;
    let active = true; setSaveStatus('saving');
    saveQueue.current = saveQueue.current.catch(() => {}).then(() => saveData(data));
    saveQueue.current.then(() => { if (active) setSaveStatus('saved'); }).catch(() => { if (active) { setSaveStatus('error'); setNotice('لم يتم الحفظ. قد تكون مساحة الجهاز ممتلئة؛ لا تغلق التطبيق قبل معالجة المشكلة.'); } });
    return () => { active = false; };
  }, [data, ready]);
  useEffect(() => {
    if (!ready) return;
    const capture = () => setData(current => { const history = captureDoses(current); return JSON.stringify(history) === JSON.stringify(current.medicationHistory) ? current : { ...current, medicationHistory: history }; });
    capture(); const timer = setInterval(capture, 30000); return () => clearInterval(timer);
  }, [ready, data.medications]);
  useEffect(() => { if (!ready) return; reminderQueue.current = reminderQueue.current.catch(() => {}).then(() => syncReminders(data)); }, [data.tasks, data.medications, data.preferences.reminders, ready]);
  useEffect(() => {
    if (!ready) return;
    const check = () => {
      const now = new Date(); const time = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      const day = today(); const items = [
        ...data.tasks.filter(t => t.day === day && t.time === time && !t.completed).map(t => ({ id: t.id, text: `حان وقت ${t.title}` })),
        ...data.medications.filter(m => m.times.includes(time) && !m.taken.includes(`${day}:${time}`)).map(m => ({ id: m.id, text: `حان وقت دواء ${m.name}، ${m.dose}` })),
      ];
      items.forEach(item => { const key = `${day}:${time}:${item.id}`; if (announced.current.has(key)) return; announced.current.add(key); setNotice(item.text); if (data.mode === 'blind') void speakArabic(item.text); if (data.mode === 'deaf') Vibration.vibrate([0, 250, 180, 250]); });
    };
    check(); const timer = setInterval(check, 15000); return () => clearInterval(timer);
  }, [data, ready]);
  const setMode = useCallback((mode: Mode) => { setData(d => ({ ...d, mode })); if (mode === 'blind') void speakArabic('تم تفعيل الوضع الصوتي. المس الأزرار لسماعها. زر إعادة القراءة في أعلى الشاشة.'); }, []);
  const updatePreferences = useCallback((patch: Partial<AppData['preferences']>) => setData(d => ({ ...d, preferences: { ...d.preferences, ...patch } })), []);
  const updateProfile = useCallback((profile: Profile) => setData(d => ({ ...d, profile })), []);
  const addTask = useCallback((task: Omit<Task, 'id' | 'completed' | 'day'>, id?: string) => setData(d => ({ ...d, tasks: id ? d.tasks.map(t => t.id === id ? { ...t, ...task } : t) : [...d.tasks, { ...task, id: uid(), day: today(), completed: false }] })), []);
  const toggleTask = useCallback((id: string) => setData(d => ({ ...d, tasks: d.tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t) })), []);
  const deleteTask = useCallback((id: string) => setData(d => ({ ...d, tasks: d.tasks.filter(t => t.id !== id) })), []);
  const addMedication = useCallback((med: Omit<Medication, 'id' | 'taken'>, id?: string) => setData(d => ({ ...d, medications: id ? d.medications.map(m => m.id === id ? { ...m, ...med } : m) : [...d.medications, { ...med, id: uid(), taken: [] }] })), []);
  const takeMedication = useCallback((id: string, time: string) => setData(d => ({ ...d, medications: d.medications.map(m => { if (m.id !== id) return m; const key = `${today()}:${time}`; return { ...m, taken: m.taken.includes(key) ? m.taken.filter(t => t !== key) : [...m.taken, key] }; }) })), []);
  const deleteMedication = useCallback((id: string) => setData(d => ({ ...d, medications: d.medications.filter(m => m.id !== id) })), []);
  const addNote = useCallback((note: Omit<Note, 'id' | 'created'>) => setData(d => ({ ...d, notes: [{ ...note, id: uid(), created: new Date().toISOString() }, ...d.notes] })), []);
  const deleteNote = useCallback((id: string) => setData(d => ({ ...d, notes: d.notes.filter(n => n.id !== id) })), []);
  const addPhrase = useCallback((text: string) => setData(d => ({ ...d, phrases: [...d.phrases, { id: uid(), text, category: 'عباراتي', icon: 'chatbubble-outline' }] })), []);
  const deletePhrase = useCallback((id: string) => setData(d => ({ ...d, phrases: d.phrases.filter(p => p.id !== id) })), []);
  const addReference = useCallback((card: Omit<ReferenceCard, 'id' | 'created'>) => setData(d => ({ ...d, references: [{ ...card, id: uid(), created: new Date().toISOString() }, ...d.references] })), []);
  const deleteReference = useCallback((id: string) => setData(d => ({ ...d, references: d.references.filter(r => r.id !== id) })), []);
  const restoreData = useCallback(async (next: AppData) => {
    setSaveStatus('saving');
    const restored = { ...next, preferences: { ...next.preferences, reminders: false } };
    const operation = saveQueue.current.catch(() => {}).then(() => saveData(restored));
    saveQueue.current = operation;
    try { await operation; writable.current = true; setData(restored); setReady(true); setSaveStatus('saved'); setNotice('تمت الاستعادة على هذا الجهاز. تذكيرات الهاتف متوقفة؛ أعد تفعيلها بإذنك من الإعدادات.'); }
    catch (error) { setSaveStatus('error'); throw error; }
  }, []);
  return <RafiqContext.Provider value={{ data, ready, saveStatus, notice, setNotice, setMode, updatePreferences, updateProfile, addTask, toggleTask, deleteTask, addMedication, takeMedication, deleteMedication, addNote, deleteNote, addPhrase, deletePhrase, addReference, deleteReference, restoreData }}>{children}</RafiqContext.Provider>;
}
