import { createContext, useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { AppState, Vibration } from 'react-native';
import { loadTimer, saveTimer, type TimerState } from '@/services/timerStorage';
import { playChime } from '@/services/chime';
import { speakArabic } from '@/services/localSpeech';
import { useRafiq } from '@/hooks/useRafiq';
interface RoutineTimerValue { remaining: number; duration: number; running: boolean; ready: boolean; toggle: () => void; reset: () => void; chooseMinutes: (minutes: number) => void; progress: number; display: string; phase: 'green' | 'amber' | 'red' }
export const RoutineTimerContext = createContext<RoutineTimerValue | undefined>(undefined);
export function RoutineTimerProvider({ children }: { children: ReactNode }) {
  const { data, setNotice, updatePreferences } = useRafiq();
  const [state, setState] = useState<TimerState>({ duration: 300, remaining: 300, deadline: null }); const [ready, setReady] = useState(false); const [clock, setClock] = useState(Date.now());
  const alive = useRef(true); const chimeCleanup = useRef<(() => void) | null>(null); const queue = useRef(Promise.resolve()); const stateRef = useRef(state); stateRef.current = state;
  useEffect(() => { alive.current = true; loadTimer().then(value => { if (alive.current) { if (value) setState(value); setReady(true); } }).catch(() => { if (alive.current) { setReady(true); setNotice('تعذّر استعادة المؤقت؛ يمكنك بدء مؤقت جديد.'); } }); return () => { alive.current = false; chimeCleanup.current?.(); }; }, [setNotice]);
  useEffect(() => { if (!ready) return; queue.current = queue.current.catch(() => {}).then(() => saveTimer(state)); void queue.current.catch(() => { if (alive.current) setNotice('تعذّر حفظ المؤقت محليًا.'); }); }, [state, ready, setNotice]);
  useEffect(() => { if (!state.deadline) return; const tick = () => setClock(Date.now()); tick(); const timer = setInterval(tick, 250); const subscription = AppState.addEventListener('change', value => { if (value === 'active') tick(); }); return () => { clearInterval(timer); subscription.remove(); }; }, [state.deadline]);
  const remaining = state.deadline ? Math.max(0, Math.ceil((state.deadline - clock) / 1000)) : state.remaining;
  useEffect(() => {
    if (!ready || !state.deadline || remaining > 0) return;
    setState(s => ({ ...s, deadline: null, remaining: 0 }));
    setNotice('انتهى وقت الروتين. خذ وقتك؛ يمكنك الراحة أو الانتقال إلى الخطوة التالية.');
    if (data.mode === 'deaf') Vibration.vibrate([0, 160, 160, 160]);
    if (data.mode === 'blind') void speakArabic('انتهى وقت الروتين. أحسنت.');
    if (data.preferences.timerChime) void playChime().then(cleanup => { if (alive.current) chimeCleanup.current = cleanup; else cleanup(); }).catch(() => { if (alive.current) setNotice('انتهى الوقت. لم يتوفر الجرس على هذا الجهاز.'); });
  }, [ready, state.deadline, remaining, data.mode, data.preferences.timerChime, setNotice]);
  const toggle = useCallback(() => setState(s => { if (s.deadline) return { ...s, remaining: Math.max(0, Math.ceil((s.deadline - Date.now()) / 1000)), deadline: null }; const seconds = s.remaining || s.duration; setClock(Date.now()); return { ...s, remaining: seconds, deadline: Date.now() + seconds * 1000 }; }), []);
  const reset = useCallback(() => setState(s => ({ ...s, remaining: s.duration, deadline: null })), []);
  const chooseMinutes = useCallback((minutes: number) => { const value = Math.max(1, Math.min(60, Math.round(minutes))); updatePreferences({ timerMinutes: value }); setState({ duration: value * 60, remaining: value * 60, deadline: null }); }, [updatePreferences]);
  const progress = Math.max(0, Math.min(1, remaining / state.duration));
  const display = `${String(Math.floor(remaining / 60)).padStart(2, '0')}:${String(remaining % 60).padStart(2, '0')}`;
  return <RoutineTimerContext.Provider value={{ remaining, duration: state.duration, running: state.deadline !== null, ready, toggle, reset, chooseMinutes, progress, display, phase: progress > 0.5 ? 'green' : progress > 0.2 ? 'amber' : 'red' }}>{children}</RoutineTimerContext.Provider>;
}
