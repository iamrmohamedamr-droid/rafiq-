import type { ComponentProps } from 'react';
import { Ionicons } from '@expo/vector-icons';
export type IconName = ComponentProps<typeof Ionicons>['name'];
export type Mode = 'blind' | 'deaf' | 'motor' | 'cognitive' | 'speech';
export const modes: { id: Mode; title: string; short: string; description: string; icon: IconName }[] = [
  { id: 'blind', title: 'المكفوفون وضعاف البصر', short: 'الوضع الصوتي', description: 'قراءة صوتية وتباين واضح وأزرار كبيرة', icon: 'eye-outline' },
  { id: 'deaf', title: 'الصم وضعاف السمع', short: 'الوضع المرئي', description: 'تنبيهات مرئية وعبارات تواصل سريعة', icon: 'ear-outline' },
  { id: 'motor', title: 'الإعاقة الحركية', short: 'الوضع الحركي', description: 'لمسات سهلة وأزرار أكبر وخطوات بسيطة', icon: 'hand-left-outline' },
  { id: 'cognitive', title: 'الدعم الإدراكي والتوحد', short: 'الوضع الهادئ', description: 'روتين واضح وخطوات قصيرة وهادئة', icon: 'leaf-outline' },
  { id: 'speech', title: 'صعوبات النطق', short: 'لوحة التواصل', description: 'صور وعبارات عربية تُنطق بلمسة', icon: 'chatbubbles-outline' },
];
export const periods = [{ id: 'all', label: 'الكل' }, { id: 'morning', label: 'الصباح' }, { id: 'afternoon', label: 'الظهيرة' }, { id: 'evening', label: 'المساء' }] as const;
export const categories = ['الكل', 'احتياجاتي', 'مشاعري', 'المساعدة', 'عباراتي'];
export const phraseSeed = [
  { id: 'water', text: 'أحتاج إلى ماء', icon: 'water-outline' as IconName, category: 'احتياجاتي' },
  { id: 'food', text: 'أريد أن آكل', icon: 'restaurant-outline' as IconName, category: 'احتياجاتي' },
  { id: 'rest', text: 'أحتاج إلى الراحة', icon: 'bed-outline' as IconName, category: 'احتياجاتي' },
  { id: 'bath', text: 'أحتاج إلى الحمام', icon: 'person-outline' as IconName, category: 'احتياجاتي' },
  { id: 'happy', text: 'أنا سعيد', icon: 'happy-outline' as IconName, category: 'مشاعري' },
  { id: 'pain', text: 'أشعر بالألم', icon: 'heart-outline' as IconName, category: 'مشاعري' },
  { id: 'help', text: 'أحتاج إلى مساعدتك', icon: 'hand-left-outline' as IconName, category: 'المساعدة' },
  { id: 'wait', text: 'انتظر قليلًا من فضلك', icon: 'time-outline' as IconName, category: 'المساعدة' },
  { id: 'yes', text: 'نعم، شكرًا', icon: 'checkmark-circle-outline' as IconName, category: 'المساعدة' },
  { id: 'no', text: 'لا، شكرًا', icon: 'close-circle-outline' as IconName, category: 'المساعدة' },
];
