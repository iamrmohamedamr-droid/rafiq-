import type { IconName } from './config';
export interface QuickHelpCard { id: string; title: string; icon: IconName; text: string }
export const quickHelpCards: QuickHelpCard[] = [
  { id: 'pharmacy', title: 'في الصيدلية', icon: 'medkit-outline', text: 'أحتاج إلى مساعدتك في قراءة اسم الدواء والجرعة كما في وصفتي. اكتب التعليمات بوضوح، ولا تغيّر الجرعة دون الرجوع إلى الطبيب.' },
  { id: 'transport', title: 'في المواصلات', icon: 'bus-outline', text: 'أحتاج إلى المساعدة في الوصول إلى وسيلة النقل المناسبة. أخبرني بالمحطة والاتجاه، واسألني قبل أن تساعدني على الحركة.' },
  { id: 'shopping', title: 'أثناء التسوق', icon: 'cart-outline', text: 'أحتاج إلى مساعدتك في العثور على المنتج وقراءة السعر والمعلومات المكتوبة عليه. أعطني وقتًا للاختيار.' },
  { id: 'medical', title: 'عند الطبيب', icon: 'medical-outline', text: 'اشرح لي الخطوات بجمل قصيرة وواضحة. أخبرني قبل لمس جسمي. يمكنني عرض معلوماتي الطبية من بطاقة الطوارئ.' },
  { id: 'public', title: 'طلب مساعدة عامة', icon: 'hand-left-outline', text: 'أحتاج إلى مساعدة. اسألني أولًا عن الطريقة المناسبة. تحدث معي مباشرة وبهدوء، وانتظر حتى أرد.' },
];
