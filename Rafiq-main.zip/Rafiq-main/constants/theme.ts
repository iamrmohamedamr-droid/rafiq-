export const colors = {
  background: '#F5F8F5', surface: '#FFFFFF', soft: '#EAF2EC', primary: '#245E4B', primarySoft: '#DDECE3',
  text: '#20372D', muted: '#64756C', border: '#DFE7E1', accent: '#D1A95F', accentSoft: '#F8EFDB',
  danger: '#AF3F3F', dangerSoft: '#FBEAEA', success: '#2E7350', white: '#FFFFFF', overlay: '#14271DBB',
  darkBackground: '#14221B', darkSurface: '#20332A', darkSoft: '#293F33', darkText: '#F2F7F3', darkMuted: '#BED0C3',
  black: '#000000', yellow: '#FFE46B', transparent: 'transparent', shadow: '#173B28', blue: '#326078', blueSoft: '#E8F0F4',
};
export type Palette = { background: string; surface: string; soft: string; primary: string; primarySoft: string; text: string; muted: string; border: string; accent: string; accentSoft: string; danger: string; dangerSoft: string; success: string; white: string; overlay: string };
export const spacing = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32, xxl: 48 };
export const radius = { sm: 12, md: 20, lg: 28, pill: 99 };
export const typography = { small: 14, body: 16, section: 20, title: 28, hero: 36 };
export function getPalette(dark: boolean, contrast: boolean): Palette {
  if (contrast) return { ...colors, background: colors.black, surface: colors.black, soft: colors.darkSoft, primary: colors.yellow, primarySoft: colors.darkSoft, text: colors.white, muted: colors.white, border: colors.white, accent: colors.yellow, danger: colors.yellow, success: colors.yellow };
  if (dark) return { ...colors, background: colors.darkBackground, surface: colors.darkSurface, soft: colors.darkSoft, primary: '#9BD6B6', primarySoft: colors.darkSoft, text: colors.darkText, muted: colors.darkMuted, border: '#486451', danger: '#FFAAAA', dangerSoft: '#482D2D' };
  return colors;
}
