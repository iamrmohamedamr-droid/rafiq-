# Rafiq local assistant and daily support

## Architecture

Data services (`assistant`, `progress`, `backup`, `timerStorage`, media adapters) are independent of React. Feature hooks orchestrate data, navigation, and accessibility. `RafiqProvider` synchronizes local CRUD and imports, and `RoutineTimerProvider` shares a persisted deadline across screens. Expo Router retains five core tabs; summary, references, quick help, timers, and focus are detail routes.

## Offline boundary

- Assistant intent matching normalizes Arabic characters and diacritics and uses deterministic patterns, clarification steps, and local templates. It is not a generative model and makes no model/API requests.
- Text is always available. Medication creation asks for the name, prescription dosage, 24-hour times, and explicit save confirmation. No dose advice or automatic emergency call is provided.
- Browser speech input is permitted only when `SpeechRecognition.available({processLocally:true})` reports an installed Arabic model and the recognizer supports `processLocally`. Legacy network speech recognition is never used, and the app never invokes model installation.
- Native speech input requires a build containing `expo-speech-recognition`, an installed Arabic locale, and on-device recognition support. Recognition always uses `requiresOnDeviceRecognition:true`; unsupported previews/Expo Go show the text fallback. Use the package version matching the project's Expo SDK for native builds.
- Browser output selects only Arabic voices with `localService`. iOS uses installed system Arabic voices. Android output selects only explicitly local voice identifiers; unverifiable or network voices are not used. Lack of local speech never blocks text actions.
- Chimes are synthesized into a small WAV locally. Connectivity indicators use OS/browser connectivity events, not an external internet-probe URL.
- All new media reads are limited to data/blob/file/content local sources. No HTTP media download is performed by these features.
- Initial app assets still have to be installed/loaded once. Published web shell caching remains separate from offline record storage and is intentionally disabled in editor preview.

## Progress meaning

Dose records snapshot schedules on days the app observes and preserve explicit confirmations, including confirmations from the prior data format. No missing days are fabricated. Confirmation indicates a user's saved action, not clinically verified adherence. Historical snapshots survive medication edits/deletion. Today's task completion is computed from actual task records.

## Timers and focus

Timer duration, remaining time, and deadline are stored under `rafiq.timer.v1`. Wall-clock time is recomputed when returning to the app. Notifications/chimes are not guaranteed while the app is closed. Focus displays the earliest incomplete task for today and completes one task at a time through the shared provider.

## Backup format and security

JSON envelope: `format: rafiq-local-backup`, `version: 2`, `createdAt`, `data`. Notes and reference media are embedded as base64 data URIs rather than nonportable device paths. Imports validate shape, dates, times, identifiers, preferences, and media schemes before prompting for replacement. Size limit: 32 MiB. Native imports materialize media into the app document folder. Failed file materialization is rolled back; failed record writes do not replace in-memory records.

Backups include profile, preferences, phrases, task records, medicines, recorded dose history, notes, reference cards, and their media. They are not encrypted. The user must protect files containing medical information. Native export uses the OS file/share interface; any onward sharing is chosen by the user, not performed by an app API. Restore explicitly replaces current data, resets the routine timer to the saved preferred duration, and disables phone reminders until permission is re-enabled locally. An active running timer session is not carried into a restored backup.

## Manual verification

1. With network disabled, open the installed app and run `اقرأ جدولي`, `ماذا عندي اليوم`, `افتح الطوارئ`, `كرر`, `بدل الوضع إلى المكفوفين`, and `اقرأ آخر ملاحظة`.
2. Run `سجل دواء`, enter prescription details, cancel, and verify no record was created; repeat and explicitly save.
3. Confirm/unconfirm a dose; open the summary and verify the stored confirmation count. An unobserved prior day must show no saved records.
4. Create a photo/voice reference and recall it offline after restarting. Unsupported microphones must leave photo/text functionality usable.
5. Start a timer, navigate away, pause/restart, and reopen after its deadline. No duplicate completion cues should occur. Changing duration resets it.
6. Complete one task in focus and verify the home/schedule/summary synchronize immediately.
7. Export a backup, change local data, import and confirm replacement. Verify embedded media, preferences, phrases, and confirmations. Reject malformed JSON, wrong versions, oversized files, and HTTP media URIs without changing current data.
8. Verify reduced-motion settings suppress the assistant's visual pulse, deaf mode shows text cues, and unavailable local speech produces an Arabic text fallback without network recognition.
