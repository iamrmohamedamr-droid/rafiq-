import { Stack } from 'expo-router';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { useFonts, Cairo_400Regular, Cairo_700Bold } from '@expo-google-fonts/cairo';
import { colors } from '@/constants/theme';
import { useOfflineShell } from '@/hooks/useOfflineShell';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AlertProvider } from '@/template';
import { RafiqProvider } from '@/contexts/RafiqContext';
import { RoutineTimerProvider } from '@/contexts/RoutineTimerContext';
import { useDesign } from '@/hooks/useDesign';
function Navigation() { const { palette } = useDesign(); const [fontsLoaded, fontError] = useFonts({ Cairo_400Regular, Cairo_700Bold }); useOfflineShell(); if (!fontsLoaded && !fontError) return <View style={[styles.loading, { backgroundColor: palette.background }]}><ActivityIndicator accessibilityLabel="تحميل رفيقك" color={palette.primary} /></View>; return <><StatusBar style={palette.background === colors.black || palette.background === colors.darkBackground ? 'light' : 'dark'} /><Stack initialRouteName="(tabs)" screenOptions={{ headerShown: false, contentStyle: { backgroundColor: palette.background }, headerStyle: { backgroundColor: palette.surface }, headerTintColor: palette.primary, headerTitleStyle: { fontFamily: 'Cairo_700Bold', fontSize: 20, color: palette.text }, animation: 'none' }}><Stack.Screen name="(tabs)" /><Stack.Screen name="summary" options={{ headerShown: true, title: 'ملخص المتابعة' }} /><Stack.Screen name="quick-help" options={{ headerShown: true, title: 'بطاقات المساعدة السريعة' }} /><Stack.Screen name="references" options={{ headerShown: true, title: 'بطاقات مرجعية بصوت وصورة' }} /><Stack.Screen name="timers" options={{ headerShown: true, title: 'مؤقتات الروتين' }} /><Stack.Screen name="focus" options={{ headerShown: true, title: 'وضع التركيز' }} /></Stack></>; }
export function RootLayout() { return <AlertProvider><SafeAreaProvider><RafiqProvider><RoutineTimerProvider><Navigation /></RoutineTimerProvider></RafiqProvider></SafeAreaProvider></AlertProvider>; }
export default RootLayout;
const styles = StyleSheet.create({ loading: { flex: 1, justifyContent: 'center', alignItems: 'center' } });
