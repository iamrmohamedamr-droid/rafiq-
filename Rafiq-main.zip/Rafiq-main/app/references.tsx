import { ReferenceCards } from '@/components/feature/ReferenceCards';
export function ReferencesPage() { return <ReferenceCards />; }
export default ReferencesPage;
