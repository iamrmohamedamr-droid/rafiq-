import { ProgressSummary } from '@/components/feature/ProgressSummary';
export function SummaryPage() { return <ProgressSummary />; }
export default SummaryPage;
