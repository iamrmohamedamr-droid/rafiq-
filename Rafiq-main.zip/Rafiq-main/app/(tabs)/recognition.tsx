import { RecognitionCamera } from '@/components/feature/RecognitionCamera';
export function RecognitionPage() { return <RecognitionCamera />; }
export default RecognitionPage;
