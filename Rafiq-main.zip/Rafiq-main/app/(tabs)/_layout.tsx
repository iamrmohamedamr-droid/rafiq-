import { Platform } from 'react-native';
import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useDesign } from '@/hooks/useDesign';
import { useDevice } from '@/hooks/useDevice';
import { radius } from '@/constants/theme';
export function TabLayout() {
  const insets = useSafeAreaInsets(); const { palette } = useDesign(); const { wide } = useDevice();
  return <Tabs screenOptions={{ headerShown: false, tabBarActiveTintColor: palette.primary, tabBarInactiveTintColor: palette.muted, tabBarHideOnKeyboard: true, tabBarLabelStyle: { fontSize: wide ? 14 : 10, fontWeight: '600', writingDirection: 'rtl', textAlign: 'center', includeFontPadding: false }, tabBarItemStyle: { borderRadius: radius.sm }, tabBarStyle: { flexDirection: 'row-reverse', height: Platform.select({ ios: insets.bottom + 60, android: insets.bottom + 60, default: 70 }), paddingTop: 8, paddingBottom: Platform.select({ ios: insets.bottom + 8, android: insets.bottom + 8, default: 8 }), paddingHorizontal: 16, backgroundColor: palette.surface, borderTopColor: palette.border, borderTopWidth: 1 } }}>
    <Tabs.Screen name="index" options={{ title: 'الرئيسية', tabBarAccessibilityLabel: 'الرئيسية', tabBarIcon: ({ color, size }) => <Ionicons name="home-outline" size={size} color={color} /> }} />
    <Tabs.Screen name="schedule" options={{ title: 'جدولي', tabBarAccessibilityLabel: 'جدولي', tabBarIcon: ({ color, size }) => <Ionicons name="calendar-outline" size={size} color={color} /> }} />
    <Tabs.Screen name="communication" options={{ title: 'التواصل والمساعدة', tabBarAccessibilityLabel: 'التواصل والمساعدة', tabBarIcon: ({ color, size }) => <Ionicons name="chatbubbles-outline" size={size} color={color} /> }} />
    <Tabs.Screen name="recognition" options={{ title: 'التعرف', tabBarAccessibilityLabel: 'التعرف', tabBarIcon: ({ color, size }) => <Ionicons name="scan-outline" size={size} color={color} /> }} />
    <Tabs.Screen name="settings" options={{ title: 'الإعدادات', tabBarAccessibilityLabel: 'الإعدادات', tabBarIcon: ({ color, size }) => <Ionicons name="settings-outline" size={size} color={color} /> }} />
  </Tabs>;
}
export default TabLayout;
