import { CommunicationBoard } from '@/components/feature/CommunicationBoard';
export function CommunicationPage() { return <CommunicationBoard />; }
export default CommunicationPage;
