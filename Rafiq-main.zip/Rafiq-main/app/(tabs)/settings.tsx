import { SettingsPanel } from '@/components/feature/SettingsPanel';
export function SettingsPage() { return <SettingsPanel />; }
export default SettingsPage;
