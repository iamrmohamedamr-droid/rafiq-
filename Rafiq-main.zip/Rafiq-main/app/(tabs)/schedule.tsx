import { ScheduleBoard } from '@/components/feature/ScheduleBoard';
export function SchedulePage() { return <ScheduleBoard />; }
export default SchedulePage;
