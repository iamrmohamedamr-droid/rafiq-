import { HomeDashboard } from '@/components/feature/HomeDashboard';
export function HomePage() { return <HomeDashboard />; }
export default HomePage;
