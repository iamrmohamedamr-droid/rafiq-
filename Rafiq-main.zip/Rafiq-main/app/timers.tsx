import { RoutineTimerPanel } from '@/components/feature/RoutineTimerPanel';
export function TimersPage() { return <RoutineTimerPanel />; }
export default TimersPage;
