import { ScrollViewStyleReset } from 'expo-router/html';
import type { PropsWithChildren } from 'react';
import { colors } from '@/constants/theme';
export function Html({ children }: PropsWithChildren) { return <html lang="ar" dir="rtl"><head><meta charSet="utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1" /><meta name="theme-color" content={colors.primary} /><link rel="manifest" href="/manifest.json" /><link rel="icon" type="image/png" href="/rafiq-icon.png" /><link rel="apple-touch-icon" href="/rafiq-icon.png" /><title>رفيقك | معك خطوة بخطوة</title><ScrollViewStyleReset /><style dangerouslySetInnerHTML={{ __html: `html,body{background:${colors.background}}body{margin:0}*:focus-visible{outline:3px solid ${colors.primary};outline-offset:3px}input,textarea{font-family:inherit} @media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}` }} /></head><body>{children}</body></html>; }
export default Html;
