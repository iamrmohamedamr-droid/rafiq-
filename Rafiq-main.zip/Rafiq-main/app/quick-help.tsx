import { QuickHelpCards } from '@/components/feature/QuickHelpCards';
export function QuickHelpPage() { return <QuickHelpCards />; }
export default QuickHelpPage;
