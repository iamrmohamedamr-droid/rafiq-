import { FocusTask } from '@/components/feature/FocusTask';
export function FocusPage() { return <FocusTask />; }
export default FocusPage;
