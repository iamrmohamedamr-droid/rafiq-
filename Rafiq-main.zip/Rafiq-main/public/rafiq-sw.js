/* Published Expo web shell cache. No user records or third-party requests are sent anywhere. */
const cacheName = 'rafiq-shell-v1';
self.addEventListener('install', event => {
  event.waitUntil(caches.open(cacheName).then(cache => cache.add('/')).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('rafiq-shell-') && key !== cacheName).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('message', event => {
  if (event.data?.type !== 'CACHE_RAFIQ' || !Array.isArray(event.data.urls)) return;
  event.waitUntil(caches.open(cacheName).then(cache => Promise.all(event.data.urls.filter(url => { try { return new URL(url).origin === self.location.origin; } catch { return false; } }).map(async url => { try { const response = await fetch(url); if (response.ok) await cache.put(url, response); } catch {} }))));
});
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET' || new URL(event.request.url).origin !== self.location.origin) return;
  event.respondWith((async () => {
    const cache = await caches.open(cacheName);
    if (event.request.mode === 'navigate') {
      try { const response = await fetch(event.request); if (response.ok) await cache.put(event.request, response.clone()); return response; }
      catch { return (await cache.match(event.request)) || (await cache.match('/')) || Response.error(); }
    }
    const cached = await cache.match(event.request);
    if (cached) return cached;
    try { const response = await fetch(event.request); if (response.ok) await cache.put(event.request, response.clone()); return response; }
    catch { return Response.error(); }
  })());
});
