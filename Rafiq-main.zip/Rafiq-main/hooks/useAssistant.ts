import { useCallback, useEffect, useRef, useState } from 'react';
import { Vibration } from 'react-native';
import { useRouter } from 'expo-router';
import { useRafiq } from './useRafiq';
import { useVoice } from './useVoice';
import { useMedia } from './useMedia';
import { startLocalVoice } from '@/services/voiceInput';
import { stopSpeech } from '@/services/localSpeech';
import type { VoiceSession } from '@/services/voiceInput.types';
import { draftMedication, parseMedicationTimes, normalizeArabic, resolveCommand, type AssistantReply, type MedicationDraft } from '@/services/assistant';
export function useAssistant(visible: boolean, onClose: () => void) {
  const app = useRafiq(); const { speak } = useVoice(); const media = useMedia(); const router = useRouter();
  const [input, setInput] = useState(''); const [reply, setReply] = useState<AssistantReply>({ text: 'أنا مساعدك المحلي. اكتب أمرًا أو اختر خيارًا. لا أستخدم خدمات سحابية.', action: 'none', chips: ['اقرأ جدولي', 'ماذا أفعل الآن', 'سجل دواء'] });
  const [emergency, setEmergency] = useState(false); const [listening, setListening] = useState(false); const [voiceBusy, setVoiceBusy] = useState(false); const [voiceStatus, setVoiceStatus] = useState('الصوت مشروط بتوفر نموذج عربي محلي؛ النص متاح دائمًا.'); const [flash, setFlash] = useState(false);
  const [draft, setDraft] = useState<MedicationDraft | null>(null); const [step, setStep] = useState<'name' | 'dose' | 'times' | 'confirm'>('name');
  const session = useRef<VoiceSession | null>(null); const alive = useRef(true); const visibleRef = useRef(visible); visibleRef.current = visible; const voiceBusyRef = useRef(false); const flashTimer = useRef<ReturnType<typeof setTimeout> | null>(null); const replyRef = useRef(reply); replyRef.current = reply;
  useEffect(() => { alive.current = true; return () => { alive.current = false; session.current?.cancel(); if (flashTimer.current) clearTimeout(flashTimer.current); }; }, []);
  useEffect(() => { if (!visible) { session.current?.cancel(); session.current = null; setListening(false); setVoiceBusy(false); } else if (app.data.mode === 'blind') void speak(replyRef.current.text); }, [visible, app.data.mode, speak]);
  const repeat = useCallback(() => { const last = replyRef.current; if (last.audioUri) void media.play(last.audioUri); else void speak(last.text); }, [speak, media.play]);
  const show = useCallback((next: AssistantReply) => {
    setReply(next);
    if (app.data.mode === 'blind') { if (next.audioUri) void media.play(next.audioUri); else void speak(next.text); }
    if (app.data.mode === 'deaf') { Vibration.vibrate([0, 120, 120, 120]); if (!app.data.preferences.reducedMotion) { setFlash(true); if (flashTimer.current) clearTimeout(flashTimer.current); flashTimer.current = setTimeout(() => { if (alive.current) setFlash(false); }, 220); } }
  }, [app.data.mode, app.data.preferences.reducedMotion, speak, media.play]);
  const send = useCallback((command: string) => {
    if (!command.trim()) return;
    setInput(''); const text = normalizeArabic(command);
    if (draft) {
      if (/^(الغاء|الغ|اوقف|لا)$/.test(text)) { setDraft(null); show({ text: 'تم الإلغاء. لم يُحفظ دواء.', action: 'none', chips: ['اقرأ جدولي', 'سجل دواء'] }); return; }
      const response = (message: string, chips = ['إلغاء']) => show({ text: message, action: 'none', chips });
      if (step === 'name') { if (command.trim().length > 120) { response('اكتب اسمًا أقصر كما في الوصفة.'); return; } setDraft({ ...draft, name: command.trim() }); setStep('dose'); response('ما الجرعة المكتوبة في وصفة الطبيب؟ لا أحدد الجرعة من تلقاء نفسي.'); return; }
      if (step === 'dose') { if (command.trim().length > 240) { response('اكتب الجرعة بجملة قصيرة كما في الوصفة.'); return; } setDraft({ ...draft, dose: command.trim() }); setStep('times'); response('ما المواعيد؟ اكتب بصيغة 08:00، 20:00.'); return; }
      if (step === 'times') { const next = { ...draft, times: parseMedicationTimes(command) }; if (!draftMedication(next)) { response('اكتب مواعيد صالحة بنظام ٢٤ ساعة مثل 08:00، 20:00.'); return; } setDraft(next); setStep('confirm'); response(`الدواء: ${next.name}. الجرعة: ${next.dose}. المواعيد: ${next.times.join('، ')}. هل نحفظه؟`, ['حفظ الدواء', 'إلغاء']); return; }
      if (step === 'confirm') { if (/^(حفظ الدواء|احفظ|نعم|حفظ)$/.test(text)) { const medicine = draftMedication(draft); if (medicine) { app.addMedication(medicine); setDraft(null); show({ text: 'تم حفظ الدواء محليًا حسب المعلومات التي أدخلتها.', action: 'none', chips: ['اقرأ أدويتي', 'اقرأ جدولي'] }); } } else response('اختر حفظ الدواء أو إلغاء. لن أحفظه دون تأكيدك.', ['حفظ الدواء', 'إلغاء']); return; }
    }
    const next = resolveCommand(command, app.data);
    if (next.action === 'repeat') { repeat(); return; }
    if (next.action === 'mode' && next.mode) app.setMode(next.mode);
    if (next.action === 'emergency') setEmergency(true);
    if (next.action === 'medication') { setDraft({ name: '', dose: '', times: [] }); setStep('name'); next.chips = ['إلغاء']; }
    show(next);
    if (/^(افتح|انتقل الي|اعرض)\s/.test(text)) {
      const destination = next.action === 'schedule' ? '/(tabs)/schedule' : next.action === 'summary' ? '/summary' : next.action === 'focus' ? '/focus' : next.action === 'timer' ? '/timers' : next.action === 'help' ? '/quick-help' : next.action === 'references' ? '/references' : next.action === 'settings' ? '/(tabs)/settings' : null;
      if (destination) { onClose(); router.push(destination); }
    }
  }, [draft, step, app.data, app.addMedication, app.setMode, show, repeat, onClose, router]);
  const openResult = useCallback(() => { const action = reply.action; onClose(); if (action === 'schedule') router.push('/(tabs)/schedule'); else if (action === 'settings') router.push('/(tabs)/settings'); else if (action === 'focus') router.push('/focus'); else if (action === 'summary') router.push('/summary'); else if (action === 'timer') router.push('/timers'); else if (action === 'help') router.push('/quick-help'); else if (action === 'references') router.push('/references'); }, [reply.action, onClose, router]);
  const startVoice = useCallback(async () => {
    if (session.current || voiceBusyRef.current) return;
    voiceBusyRef.current = true; setVoiceBusy(true); await stopSpeech();
    try { const current = await startLocalVoice({ onText: value => { if (alive.current && visibleRef.current) send(value); }, onEnd: () => { if (alive.current) { setListening(false); setVoiceStatus('انتهى الاستماع المحلي.'); } const old = session.current; session.current = null; old?.cancel(); }, onError: message => { if (alive.current) { setListening(false); setVoiceStatus(message); } session.current?.cancel(); session.current = null; } }); if (!alive.current || !visibleRef.current) current.cancel(); else { session.current = current; setListening(true); setVoiceStatus('أستمع محليًا. قل أمرًا قصيرًا.'); } }
    catch (error) { if (alive.current && visibleRef.current) { const message = error instanceof Error && /[\u0600-\u06FF]/.test(error.message) ? error.message : 'الصوت المحلي غير متاح. استخدم النص أو الخيارات.'; setVoiceStatus(message); if (app.data.mode === 'blind') void speak(message); } }
    finally { voiceBusyRef.current = false; if (alive.current) setVoiceBusy(false); }
  }, [send, app.data.mode, speak]);
  const stopVoice = useCallback(() => { session.current?.stop(); }, []);
  return { input, setInput, reply, send, repeat, openResult, draft, step, emergency, setEmergency, listening, voiceBusy, voiceStatus, startVoice, stopVoice, flash };
}
