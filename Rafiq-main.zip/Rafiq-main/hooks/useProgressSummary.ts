import { useEffect, useMemo, useState } from 'react';
import { dailyProgress, recentDays } from '@/services/progress';
import { today } from '@/services/storage';
import { useRafiq } from './useRafiq';
export function useProgressSummary() { const { data } = useRafiq(); const [day, setDay] = useState(today()); useEffect(() => { const timer = setInterval(() => setDay(today()), 30000); return () => clearInterval(timer); }, []); const current = useMemo(() => dailyProgress(data, day), [data, day]); const history = useMemo(() => recentDays().map(date => ({ day: date, ...dailyProgress(data, date) })), [data, day]); const notes = useMemo(() => [...data.notes].sort((a, b) => b.created.localeCompare(a.created)).slice(0, 5), [data.notes]); return { data, current, history, notes }; }
