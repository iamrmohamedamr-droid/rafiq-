import { useContext } from 'react';
import { RafiqContext } from '@/contexts/RafiqContext';
export function useRafiq() { const value = useContext(RafiqContext); if (!value) throw new Error('useRafiq requires RafiqProvider'); return value; }
