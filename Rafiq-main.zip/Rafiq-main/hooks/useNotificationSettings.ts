import { useCallback, useState } from 'react';
import { Platform } from 'react-native';
import { useRafiq } from './useRafiq';
import { enableReminders } from '@/services/notifications';
export function useNotificationSettings() {
  const { data, updatePreferences, setNotice } = useRafiq(); const [busy, setBusy] = useState(false);
  const requestNotifications = useCallback(async () => {
    if (data.preferences.reminders) { updatePreferences({ reminders: false }); return; }
    setBusy(true);
    try { const granted = await enableReminders(); if (granted) { updatePreferences({ reminders: true }); setNotice('تم تفعيل تذكيرات الهاتف المحلية'); } else setNotice(Platform.OS === 'web' ? 'تذكيرات الخلفية غير متاحة في المتصفح. استخدم تطبيق الهاتف؛ التنبيهات داخل التطبيق تعمل هنا.' : 'الإشعارات غير متاحة أو لم يُمنح الإذن. اسمح بها من إعدادات الهاتف؛ التنبيهات داخل التطبيق ما زالت تعمل.'); }
    finally { setBusy(false); }
  }, [data.preferences.reminders, updatePreferences, setNotice]);
  return { busy, requestNotifications };
}
