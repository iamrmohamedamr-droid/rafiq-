import { useRafiq } from './useRafiq';
import { getPalette } from '@/constants/theme';
export function useDesign() {
  const { data } = useRafiq(); const { preferences, mode } = data;
  return { palette: getPalette(preferences.dark, preferences.contrast || mode === 'blind'), scale: preferences.fontScale, large: mode === 'motor' || mode === 'blind', reducedMotion: preferences.reducedMotion };
}
