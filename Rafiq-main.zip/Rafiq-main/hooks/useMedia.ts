import { useCallback, useEffect, useRef, useState } from 'react';
import { Audio } from 'expo-av';
import { persistMedia, pickPhoto } from '@/services/media';
import { useRafiq } from './useRafiq';
export function useMedia() {
  const { setNotice } = useRafiq(); const recordingRef = useRef<Audio.Recording | null>(null); const soundRef = useRef<Audio.Sound | null>(null);
  const [recording, setRecording] = useState(false); const [busy, setBusy] = useState(false); const [playing, setPlaying] = useState(false);
  useEffect(() => () => { void recordingRef.current?.stopAndUnloadAsync(); void soundRef.current?.unloadAsync(); }, []);
  const photo = useCallback(async (camera = false) => { setBusy(true); try { return await pickPhoto(camera); } catch (error) { setNotice(error instanceof Error ? error.message : 'تعذّر فتح الصور'); return null; } finally { setBusy(false); } }, [setNotice]);
  const startRecording = useCallback(async () => {
    if (recordingRef.current || busy) return;
    setBusy(true);
    try { const permission = await Audio.requestPermissionsAsync(); if (!permission.granted) { setNotice('اسمح باستخدام الميكروفون لتسجيل ملاحظة صوتية'); return; } await Audio.setAudioModeAsync({ allowsRecordingIOS: true, playsInSilentModeIOS: true }); const result = await Audio.Recording.createAsync(Audio.RecordingOptionsPresets.HIGH_QUALITY); recordingRef.current = result.recording; setRecording(true); } catch { setNotice('التسجيل غير متاح على هذا الجهاز أو المتصفح. استخدم ملاحظة نصية.'); } finally { setBusy(false); }
  }, [busy, setNotice]);
  const stopRecording = useCallback(async () => {
    if (!recordingRef.current) return null; setBusy(true);
    try { const rec = recordingRef.current; await rec.stopAndUnloadAsync(); const uri = rec.getURI(); recordingRef.current = null; setRecording(false); await Audio.setAudioModeAsync({ allowsRecordingIOS: false }); return uri ? await persistMedia(uri, 'm4a') : null; } catch { setNotice('تعذّر حفظ التسجيل. حاول مرة أخرى.'); return null; } finally { setBusy(false); setRecording(false); recordingRef.current = null; }
  }, [setNotice]);
  const play = useCallback(async (uri: string) => { try { if (soundRef.current) { await soundRef.current.unloadAsync(); soundRef.current = null; } setPlaying(true); const { sound } = await Audio.Sound.createAsync({ uri }, { shouldPlay: true }, status => { if (status.isLoaded && status.didJustFinish) setPlaying(false); }); soundRef.current = sound; } catch { setPlaying(false); setNotice('تعذّر تشغيل هذا التسجيل'); } }, [setNotice]);
  return { photo, startRecording, stopRecording, play, playing, recording, busy };
}
