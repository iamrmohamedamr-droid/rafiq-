import { useCallback, useState } from 'react';
import { useRafiq } from './useRafiq';
import { useMedia } from './useMedia';
import { useVoice } from './useVoice';
import type { ReferenceCard } from '@/services/storage';
export function useReferenceCards() {
  const app = useRafiq(); const media = useMedia(); const { speak } = useVoice();
  const [editor, setEditor] = useState(false); const [label, setLabel] = useState(''); const [photoUri, setPhotoUri] = useState(''); const [audioUri, setAudioUri] = useState(''); const [error, setError] = useState(''); const [selected, setSelected] = useState<ReferenceCard | null>(null);
  const pick = useCallback(async (camera: boolean) => { const uri = await media.photo(camera); if (uri) { setPhotoUri(uri); setError(''); } }, [media.photo]);
  const record = useCallback(async () => { if (media.recording) { const uri = await media.stopRecording(); if (uri) setAudioUri(uri); } else await media.startRecording(); }, [media.recording, media.startRecording, media.stopRecording]);
  const save = useCallback(() => { if (!photoUri || !label.trim()) { setError('اختر صورة واكتب تسمية عربية أولًا. التسجيل اختياري.'); return; } if (media.recording) { setError('أوقف التسجيل قبل الحفظ.'); return; } app.addReference({ label: label.trim(), photoUri, audioUri: audioUri || undefined }); setEditor(false); setLabel(''); setPhotoUri(''); setAudioUri(''); setError(''); }, [photoUri, label, audioUri, media.recording, app.addReference]);
  const close = useCallback(() => { if (media.recording || media.busy) { setError('أوقف التسجيل وانتظر الحفظ أولًا.'); return; } setEditor(false); }, [media.recording, media.busy]);
  const recall = useCallback((card: ReferenceCard) => { setSelected(card); if (card.audioUri) void media.play(card.audioUri); else if (app.data.mode !== 'deaf') void speak(card.label); }, [media.play, app.data.mode, speak]);
  return { ...app, media, editor, setEditor, label, setLabel, photoUri, audioUri, error, selected, setSelected, pick, record, save, close, recall };
}
