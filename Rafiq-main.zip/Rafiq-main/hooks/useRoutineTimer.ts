import { useContext } from 'react';
import { RoutineTimerContext } from '@/contexts/RoutineTimerContext';
export function useRoutineTimer() { const context = useContext(RoutineTimerContext); if (!context) throw new Error('useRoutineTimer must be used within RoutineTimerProvider'); return context; }
