import { useCallback, useState } from 'react';
import { exportBackup, readBackup, prepareRestore } from '@/services/backup';
import type { AppData } from '@/services/storage';
import { useRafiq } from './useRafiq';
import { useRoutineTimer } from './useRoutineTimer';
export function useLocalBackup() {
  const { data, restoreData, saveStatus, ready } = useRafiq(); const timer = useRoutineTimer();
  const [busy, setBusy] = useState(false); const [message, setMessage] = useState(''); const [error, setError] = useState(''); const [pending, setPending] = useState<AppData | null>(null);
  const exportData = useCallback(async () => { if (busy || !ready) return; setBusy(true); setError(''); setMessage(''); try { setMessage(await exportBackup(data)); } catch (issue) { setError(issue instanceof Error && /[\u0600-\u06FF]/.test(issue.message) ? issue.message : 'تعذّر إنشاء النسخة المحلية.'); } finally { setBusy(false); } }, [data, busy, ready]);
  const selectFile = useCallback(async () => { if (busy) return; setBusy(true); setError(''); setMessage(''); try { const next = await readBackup(); setPending(next); if (!next) setMessage('لم يتم اختيار ملف.'); } catch (issue) { setError(issue instanceof Error && /[\u0600-\u06FF]/.test(issue.message) ? issue.message : 'تعذّر قراءة الملف. لم تتغير بياناتك.'); } finally { setBusy(false); } }, [busy]);
  const restore = useCallback(async () => { if (!pending || busy) return; setBusy(true); setError(''); let rollback: (() => Promise<void>) | undefined; try { const prepared = await prepareRestore(pending); rollback = prepared.rollback; await restoreData(prepared.data); timer.chooseMinutes(prepared.data.preferences.timerMinutes); setPending(null); setMessage('تمت استعادة البيانات والوسائط. أعد تفعيل التذكيرات إذا أردت.'); } catch (issue) { await rollback?.(); setError(issue instanceof Error && /[\u0600-\u06FF]/.test(issue.message) ? issue.message : 'تعذّرت الاستعادة. بقيت البيانات السابقة محفوظة.'); } finally { setBusy(false); } }, [pending, busy, restoreData, timer.chooseMinutes]);
  return { busy, message, error, pending, setPending, exportData, selectFile, restore, saveStatus, ready };
}
