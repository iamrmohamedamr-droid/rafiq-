import { useCallback } from 'react';
import { useRafiq } from './useRafiq';
import { speakArabic, repeatSpeech } from '@/services/localSpeech';
export function useVoice() {
  const { setNotice } = useRafiq();
  const speak = useCallback(async (text: string) => { const success = await speakArabic(text); if (!success) setNotice(`الصوت العربي غير متاح. حمّل صوتًا عربيًا من إعدادات الجهاز. النص: ${text}`); }, [setNotice]);
  const repeat = useCallback(async () => { const success = await repeatSpeech(); if (!success) setNotice('الصوت العربي غير متاح. حمّل صوتًا عربيًا محليًا من إعدادات الجهاز.'); }, [setNotice]);
  return { speak, repeat };
}
