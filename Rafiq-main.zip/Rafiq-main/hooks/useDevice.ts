import { useEffect, useState } from 'react';
import { Dimensions, Platform } from 'react-native';
import NetInfo from '@react-native-community/netinfo';
export function useDevice() {
  const [width, setWidth] = useState(375); const [online, setOnline] = useState(false);
  useEffect(() => {
    setWidth(Math.max(1, Dimensions.get('window').width || 375));
    const sub = Dimensions.addEventListener('change', ({ window: size }) => setWidth(Math.max(1, size.width || 375)));
    let unsubscribe = () => {};
    if (Platform.OS === 'web' && typeof window !== 'undefined') { const update = () => setOnline(navigator.onLine); update(); window.addEventListener('online', update); window.addEventListener('offline', update); unsubscribe = () => { window.removeEventListener('online', update); window.removeEventListener('offline', update); }; }
    else { // Connectivity only; never ping an external reachability URL.
      NetInfo.configure({ useNativeReachability: true, reachabilityShouldRun: () => false });
      unsubscribe = NetInfo.addEventListener(state => setOnline(state.isConnected === true));
    }
    return () => { sub.remove(); unsubscribe(); };
  }, []);
  return { width, wide: width >= 600, online };
}
