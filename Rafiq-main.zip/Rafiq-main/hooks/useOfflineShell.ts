import { useEffect } from 'react';
import { Platform } from 'react-native';
/** Cache only the published Expo web app, never the editor preview. */
export function useOfflineShell() {
  useEffect(() => {
    if (Platform.OS !== 'web' || __DEV__) return;
    if (typeof window === 'undefined' || !('serviceWorker' in navigator) || !window.isSecureContext) return;
    let active = true; let followup: ReturnType<typeof setTimeout> | undefined;
    const setup = async () => {
      try {
        await navigator.serviceWorker.register('/rafiq-sw.js', { scope: '/' });
        const registration = await navigator.serviceWorker.ready;
        if (!active) return;
        const urls = [window.location.href, ...performance.getEntriesByType('resource').map(entry => entry.name)].filter(url => { try { return new URL(url).origin === window.location.origin; } catch { return false; } });
        registration.active?.postMessage({ type: 'CACHE_RAFIQ', urls });
        followup = setTimeout(() => { if (!active) return; const loaded = performance.getEntriesByType('resource').map(entry => entry.name).filter(url => { try { return new URL(url).origin === window.location.origin; } catch { return false; } }); registration.active?.postMessage({ type: 'CACHE_RAFIQ', urls: loaded }); }, 5000);
      } catch { /* Local records still work; offline app shell requires HTTPS and service worker support. */ }
    };
    void setup(); return () => { active = false; if (followup) clearTimeout(followup); };
  }, []);
}
