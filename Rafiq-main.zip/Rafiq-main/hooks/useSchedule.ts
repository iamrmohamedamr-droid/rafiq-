import { useCallback, useEffect, useMemo, useState } from 'react';
import { useRafiq } from './useRafiq';
import { today, validTime, periodFor, type Task, type Medication } from '@/services/storage';
export function useSchedule() {
  const app = useRafiq(); const [day, setDay] = useState(today());
  const [tab, setTab] = useState<'tasks' | 'medications'>('tasks'); const [period, setPeriod] = useState('all');
  const [editor, setEditor] = useState<'task' | 'medication' | null>(null); const [editId, setEditId] = useState<string | undefined>(undefined);
  const [title, setTitle] = useState(''); const [time, setTime] = useState('08:00'); const [dose, setDose] = useState(''); const [error, setError] = useState('');
  useEffect(() => { const interval = setInterval(() => setDay(today()), 30000); return () => clearInterval(interval); }, []);
  const tasks = useMemo(() => app.data.tasks.filter(t => t.day === day && (period === 'all' || t.period === period)).sort((a, b) => a.time.localeCompare(b.time)), [app.data.tasks, period, day]);
  const openTask = useCallback((task?: Task) => { setEditor('task'); setEditId(task?.id); setTitle(task?.title || ''); setTime(task?.time || '08:00'); setDose(''); setError(''); }, []);
  const openMedication = useCallback((med?: Medication) => { setEditor('medication'); setEditId(med?.id); setTitle(med?.name || ''); setTime(med?.times.join('، ') || '08:00'); setDose(med?.dose || ''); setError(''); }, []);
  const save = useCallback(() => {
    if (!title.trim()) { setError('أدخل الاسم أولًا'); return; }
    const times = time.replace(/[٠-٩]/g, n => String('٠١٢٣٤٥٦٧٨٩'.indexOf(n))).split(/[,،]/).map(t => t.trim());
    if (times.some(t => !validTime(t)) || (editor === 'task' && times.length !== 1)) { setError('اكتب الوقت بصيغة 08:00؛ افصل مواعيد الدواء بفاصلة'); return; }
    if (editor === 'task') app.addTask({ title: title.trim(), time: times[0], period: periodFor(times[0]) }, editId);
    else { if (!dose.trim()) { setError('أدخل الجرعة كما وصفها الطبيب'); return; } app.addMedication({ name: title.trim(), dose: dose.trim(), times: [...new Set(times)].sort() }, editId); }
    setEditor(null);
  }, [title, time, dose, editor, editId, app]);
  return { ...app, tab, setTab, period, setPeriod, tasks, editor, setEditor, editId, title, setTitle, time, setTime, dose, setDose, error, openTask, openMedication, save };
}
