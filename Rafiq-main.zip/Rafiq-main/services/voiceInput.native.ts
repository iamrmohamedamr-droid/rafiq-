import { voiceUnavailable, type VoiceCallbacks, type VoiceSession } from './voiceInput.types';
export async function startLocalVoice(callbacks: VoiceCallbacks): Promise<VoiceSession> {
  // Missing native modules (Expo Go/preview) are a text fallback, not a cloud fallback.
  let module: typeof import('expo-speech-recognition')['ExpoSpeechRecognitionModule'];
  try { module = (await import('expo-speech-recognition')).ExpoSpeechRecognitionModule; } catch { throw new Error(voiceUnavailable); }
  if (!module.supportsOnDeviceRecognition()) throw new Error(voiceUnavailable);
  const locales = await module.getSupportedLocales({});
  const lang = locales.installedLocales.find(locale => /^ar(?:-|$)/i.test(locale));
  if (!lang) throw new Error(voiceUnavailable);
  const permission = await module.requestPermissionsAsync();
  if (!permission.granted) throw new Error('اسمح بالميكروفون والتعرف المحلي من إعدادات الجهاز، أو استخدم النص.');
  let delivered = false;
  const subscriptions = [
    module.addListener('result', event => { if (event.isFinal && !delivered && event.results[0]?.transcript) { delivered = true; callbacks.onText(event.results[0].transcript); } }),
    module.addListener('end', () => callbacks.onEnd()),
    module.addListener('error', () => callbacks.onError('تعذّر فهم الصوت محليًا. استخدم النص؛ لن نحاول اتصالًا سحابيًا.')),
  ];
  try { module.start({ lang, requiresOnDeviceRecognition: true, interimResults: false, continuous: false, maxAlternatives: 1 }); }
  catch (error) { subscriptions.forEach(s => s.remove()); throw error; }
  return { stop: () => module.stop(), cancel: () => { subscriptions.forEach(s => s.remove()); module.abort(); } };
}
