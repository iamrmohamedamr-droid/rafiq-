import * as FileSystem from 'expo-file-system';
import * as DocumentPicker from 'expo-document-picker';
import * as Sharing from 'expo-sharing';
import { uid } from './storage';
import { backupLimit } from './backupValidation';
export async function portableMedia(uri: string, kind: 'image' | 'audio'): Promise<string> {
  if (uri.startsWith('data:')) return uri;
  if (!uri.startsWith('file:') && !uri.startsWith('content:')) throw new Error('وسائط غير محلية. لا نجلب ملفات من الإنترنت.');
  const info = await FileSystem.getInfoAsync(uri); if (!info.exists || (info.size || 0) > backupLimit) throw new Error('ملف الوسائط غير موجود أو كبير جدًا.');
  const encoded = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
  const ext = uri.split('.').pop()?.toLowerCase(); const mime = kind === 'image' ? ext === 'png' ? 'image/png' : 'image/jpeg' : ext === 'wav' ? 'audio/wav' : ext === 'webm' ? 'audio/webm' : 'audio/mp4';
  return `data:${mime};base64,${encoded}`;
}
export async function materializeMedia(uri: string): Promise<string> {
  if (!FileSystem.documentDirectory) throw new Error('التخزين المحلي غير متاح.');
  const folder = `${FileSystem.documentDirectory}rafiq/`; await FileSystem.makeDirectoryAsync(folder, { intermediates: true });
  const mime = uri.slice(5, uri.indexOf(';')); const extension = mime === 'image/png' ? 'png' : mime === 'audio/wav' ? 'wav' : mime === 'audio/webm' ? 'webm' : mime.startsWith('audio/') ? 'm4a' : 'jpg';
  const destination = `${folder}${uid()}.${extension}`; await FileSystem.writeAsStringAsync(destination, uri.slice(uri.indexOf(',') + 1), { encoding: FileSystem.EncodingType.Base64 }); return destination;
}
export async function disposeMedia(uris: string[]) { await Promise.all(uris.map(uri => FileSystem.deleteAsync(uri, { idempotent: true }).catch(() => {}))); }
export async function exportFile(raw: string, filename: string): Promise<string> {
  if (!FileSystem.documentDirectory) throw new Error('التخزين المحلي غير متاح.');
  const uri = `${FileSystem.documentDirectory}${filename}`; await FileSystem.writeAsStringAsync(uri, raw, { encoding: FileSystem.EncodingType.UTF8 });
  if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(uri, { mimeType: 'application/json', UTI: 'public.json', dialogTitle: 'حفظ النسخة المحلية في الملفات' });
  return 'تم إنشاء ملف JSON محلي. استخدم الحفظ في الملفات للاحتفاظ بالنسخة خارج التطبيق.';
}
export async function pickBackupFile(): Promise<string | null> {
  const result = await DocumentPicker.getDocumentAsync({ type: ['application/json', 'text/plain', 'application/octet-stream'], copyToCacheDirectory: true });
  if (result.canceled) return null; const file = result.assets[0]; if (!file || (file.size || 0) > backupLimit) throw new Error('ملف النسخة كبير جدًا أو غير متاح.');
  const info = await FileSystem.getInfoAsync(file.uri); if (info.exists && (info.size || 0) > backupLimit) throw new Error('حجم النسخة أكبر من ٣٢ ميغابايت.');
  return FileSystem.readAsStringAsync(file.uri, { encoding: FileSystem.EncodingType.UTF8 });
}
