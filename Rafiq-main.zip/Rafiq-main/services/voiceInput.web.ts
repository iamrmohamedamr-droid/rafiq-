import { voiceUnavailable, type VoiceCallbacks, type VoiceSession } from './voiceInput.types';
interface LocalRecognizer {
  processLocally: boolean; lang: string; continuous: boolean; interimResults: boolean;
  onresult: ((event: { results: ArrayLike<{ isFinal: boolean; 0: { transcript: string } }> }) => void) | null;
  onend: (() => void) | null; onerror: (() => void) | null; start: () => void; stop: () => void; abort: () => void;
}
interface LocalRecognizerClass { new(): LocalRecognizer; available?: (options: { langs: string[]; processLocally: boolean }) => Promise<string> }
export async function startLocalVoice(callbacks: VoiceCallbacks): Promise<VoiceSession> {
  if (typeof window === 'undefined') throw new Error(voiceUnavailable);
  const browser = window as unknown as { SpeechRecognition?: LocalRecognizerClass; webkitSpeechRecognition?: LocalRecognizerClass };
  const Recognition = browser.SpeechRecognition || browser.webkitSpeechRecognition;
  if (!Recognition?.available) throw new Error(voiceUnavailable);
  // Never call install(), and never use the network-backed Web Speech API.
  const lang = 'ar-SA';
  if (await Recognition.available({ langs: [lang], processLocally: true }) !== 'available') throw new Error(voiceUnavailable);
  const session = new Recognition();
  if (!('processLocally' in session)) throw new Error(voiceUnavailable);
  session.processLocally = true; session.lang = lang; session.continuous = false; session.interimResults = false;
  let delivered = false;
  session.onresult = event => { if (delivered) return; for (let i = 0; i < event.results.length; i++) { if (event.results[i].isFinal) { delivered = true; callbacks.onText(event.results[i][0].transcript); break; } } };
  session.onerror = () => callbacks.onError('تعذّر فهم الصوت محليًا. اكتب الأمر أو اختر بطاقة.');
  session.onend = callbacks.onEnd; session.start();
  return { stop: () => session.stop(), cancel: () => { session.onresult = null; session.onend = null; session.onerror = null; session.abort(); } };
}
