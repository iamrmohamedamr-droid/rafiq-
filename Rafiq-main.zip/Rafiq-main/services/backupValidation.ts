import type { AppData } from './storage';
import { validTime } from './storage';
import { modes, phraseSeed } from '@/constants/config';
export const backupLimit = 32 * 1024 * 1024;
function fail(): never { throw new Error('ملف النسخة غير صالح أو غير متوافق. لم تتغير بياناتك الحالية.'); }
function object(value: unknown): Record<string, unknown> { if (!value || typeof value !== 'object' || Array.isArray(value)) fail(); return value as Record<string, unknown>; }
function text(value: unknown, max = 2000): string { if (typeof value !== 'string' || value.length > max) fail(); return value; }
function flag(value: unknown): boolean { if (typeof value !== 'boolean') fail(); return value; }
function items(value: unknown, max = 10000): unknown[] { if (!Array.isArray(value) || value.length > max) fail(); return value; }
function day(value: unknown): string { const result = text(value, 10); if (!/^\d{4}-\d{2}-\d{2}$/.test(result)) fail(); const d = new Date(`${result}T12:00:00`); if (!Number.isFinite(d.getTime()) || `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}` !== result) fail(); return result; }
function timestamp(value: unknown): string { const result = text(value, 40); if (!/^\d{4}-\d{2}-\d{2}T/.test(result) || !Number.isFinite(Date.parse(result))) fail(); return result; }
function time(value: unknown): string { const result = text(value, 5); if (!validTime(result)) fail(); return result; }
function id(value: unknown): string { const result = text(value, 120); if (!result) fail(); return result; }
function unique<T extends { id: string }>(value: T[]): T[] { if (new Set(value.map(v => v.id)).size !== value.length) fail(); return value; }
function media(value: unknown, kind: 'image' | 'audio'): string { const result = text(value, backupLimit); if (!new RegExp(`^data:${kind}/[a-zA-Z0-9.+-]+(?:;[^,]*)?;base64,[A-Za-z0-9+/]*={0,2}$`).test(result) || result.slice(result.indexOf(',') + 1).length % 4 !== 0) fail(); if (kind === 'image' && /svg/i.test(result.slice(0, result.indexOf(',')))) fail(); return result; }
export function parseBackup(raw: string): AppData {
  if (raw.length > backupLimit) throw new Error('حجم النسخة أكبر من ٣٢ ميغابايت. استخدم نسخة أصغر.');
  let envelope: Record<string, unknown>; try { envelope = object(JSON.parse(raw)); } catch { return fail(); }
  if (envelope.format !== 'rafiq-local-backup' || envelope.version !== 2) fail();
  timestamp(envelope.createdAt);
  const d = object(envelope.data); const p = object(d.profile); const prefs = object(d.preferences);
  if (d.mode !== null && !modes.some(m => m.id === d.mode)) fail();
  const fontScale = prefs.fontScale; if (fontScale !== 1 && fontScale !== 1.2 && fontScale !== 1.45) fail();
  const timerMinutes = prefs.timerMinutes; if (typeof timerMinutes !== 'number' || !Number.isInteger(timerMinutes) || timerMinutes < 1 || timerMinutes > 60) fail();
  const tasks = unique(items(d.tasks).map(value => { const t = object(value); if (!['morning', 'afternoon', 'evening'].includes(String(t.period))) fail(); return { id: id(t.id), title: text(t.title), time: time(t.time), period: t.period as AppData['tasks'][number]['period'], completed: flag(t.completed), day: day(t.day) }; }));
  const medications = unique(items(d.medications, 1000).map(value => { const m = object(value); const times = items(m.times, 48).map(time); if (!times.length || new Set(times).size !== times.length) fail(); return { id: id(m.id), name: text(m.name), dose: text(m.dose), times, taken: items(m.taken, 20000).map(value => { const key = text(value, 16); const match = /^(\d{4}-\d{2}-\d{2}):(\d{2}:\d{2})$/.exec(key); if (!match) fail(); day(match[1]); time(match[2]); return key; }) }; }));
  const notes = unique(items(d.notes).map(value => { const n = object(value); if (n.type !== 'text' && n.type !== 'audio' && n.type !== 'photo') fail(); const type = n.type; return { id: id(n.id), title: text(n.title), text: text(n.text, 100000), type, created: timestamp(n.created), uri: n.uri === undefined ? undefined : type === 'text' ? fail() : media(n.uri, type === 'audio' ? 'audio' : 'image') }; }));
  const references = unique(items(d.references).map(value => { const r = object(value); return { id: id(r.id), label: text(r.label), photoUri: media(r.photoUri, 'image'), audioUri: r.audioUri === undefined ? undefined : media(r.audioUri, 'audio'), created: timestamp(r.created) }; }));
  const medicationHistory = unique(items(d.medicationHistory, 50000).map(value => { const r = object(value); return { id: id(r.id), medicationId: id(r.medicationId), name: text(r.name), dose: text(r.dose), day: day(r.day), time: time(r.time), confirmed: flag(r.confirmed) }; }));
  const phrases = unique(items(d.phrases).map(value => { const r = object(value); return { id: id(r.id), text: text(r.text), category: text(r.category, 120), icon: phraseSeed.find(p => p.icon === r.icon)?.icon || 'chatbubble-outline' as const }; }));
  return { mode: d.mode as AppData['mode'], tasks, medications, notes, references, medicationHistory, phrases, profile: { name: text(p.name), blood: text(p.blood), medical: text(p.medical, 10000), contactName: text(p.contactName), contactPhone: text(p.contactPhone, 120), communication: text(p.communication, 10000), needs: text(p.needs, 10000) }, preferences: { fontScale, timerMinutes, contrast: flag(prefs.contrast), dark: flag(prefs.dark), reducedMotion: flag(prefs.reducedMotion), reminders: flag(prefs.reminders), timerChime: flag(prefs.timerChime) } };
}
