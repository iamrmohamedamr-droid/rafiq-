import AsyncStorage from '@react-native-async-storage/async-storage';
export interface TimerState { duration: number; remaining: number; deadline: number | null }
const key = 'rafiq.timer.v1';
export async function loadTimer(): Promise<TimerState | null> { const raw = await AsyncStorage.getItem(key); if (!raw) return null; const value = JSON.parse(raw); if (!Number.isFinite(value.duration) || value.duration < 60 || value.duration > 3600 || !Number.isFinite(value.remaining) || value.remaining < 0 || value.remaining > value.duration || (value.deadline !== null && !Number.isFinite(value.deadline))) return null; return value; }
export async function saveTimer(value: TimerState) { await AsyncStorage.setItem(key, JSON.stringify(value)); }
