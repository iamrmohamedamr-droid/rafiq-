import type { Mode } from '@/constants/config';
import { today, validTime, type AppData, type Medication } from './storage';
export type AssistantAction = 'none' | 'schedule' | 'medication' | 'emergency' | 'note' | 'repeat' | 'focus' | 'timer' | 'summary' | 'help' | 'references' | 'settings' | 'mode';
export interface AssistantReply { text: string; action: AssistantAction; chips: string[]; mode?: Mode; audioUri?: string }
export interface MedicationDraft { name: string; dose: string; times: string[] }
export function normalizeArabic(text: string) { return text.replace(/[\u064B-\u065F\u0670\u0640]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/[٠-٩]/g, n => String('٠١٢٣٤٥٦٧٨٩'.indexOf(n))).replace(/[؟?!،,]/g, ' ').replace(/\s+/g, ' ').trim().toLowerCase(); }
const defaultChips = ['اقرأ جدولي', 'افتح الطوارئ', 'ماذا أفعل الآن'];
export function resolveCommand(raw: string, data: AppData): AssistantReply {
  const text = normalizeArabic(raw);
  const reply = (message: string, action: AssistantAction = 'none', chips = defaultChips): AssistantReply => ({ text: message, action, chips });
  const tasks = data.tasks.filter(t => t.day === today()).sort((a, b) => a.time.localeCompare(b.time));
  const remaining = tasks.filter(t => !t.completed);
  const simple = data.mode === 'cognitive' || data.mode === 'speech';
  if (/^(كرر|اعد|اعد القراءه|كرر الرد|مره اخري)$/.test(text)) return reply('إعادة آخر رد.', 'repeat');
  if (/(طوارئ|الطواري|الطارئه)/.test(text)) return reply('هذه معلومات الطوارئ المحفوظة. لا يتم الاتصال تلقائيًا.', 'emergency');
  if (/(بدل|غير|تغيير|انتقل|حول).*(الوضع|المكفوف|الصم|الحركي|النطق|التوحد)/.test(text)) {
    const choices: [RegExp, Mode, string][] = [[/مكفوف|كفيف|بصر|صوتي/, 'blind', 'الوضع الصوتي'], [/صم|سمع|مرئي/, 'deaf', 'الوضع المرئي'], [/حرك|حركي/, 'motor', 'الوضع الحركي'], [/ادراك|توحد|هادئ/, 'cognitive', 'الوضع الهادئ'], [/نطق|تواصل|كلام/, 'speech', 'لوحة التواصل']];
    const mode = choices.find(([pattern]) => pattern.test(text));
    return mode ? { ...reply(`تم اختيار ${mode[2]}.`, 'mode'), mode: mode[1] } : reply('أي وضع تريد؟', 'none', ['بدل الوضع إلى المكفوفين', 'بدل الوضع إلى الصم', 'بدل الوضع إلى الهادئ']);
  }
  if (/(سجل|اضف|اضافه|تسجيل|احفظ).*(دواء|دوا|علاج)/.test(text)) return reply('ما اسم الدواء؟ اكتب الاسم كما في الوصفة.', 'medication', []);
  if (/(اخر|آخر).*(ملاحظه|ملاحظاتي)|اقرا ملاحظه/.test(text)) {
    const note = [...data.notes].sort((a, b) => b.created.localeCompare(a.created))[0];
    return note ? { ...reply(`${note.title}. ${note.text || (note.type === 'audio' ? 'هذه ملاحظة صوتية مسجلة.' : 'هذه ملاحظة مصورة.')}`, 'note', ['اقرأ جدولي', 'كرر']), audioUri: note.type === 'audio' ? note.uri : undefined } : reply('لم تحفظ ملاحظات بعد. يمكنك إضافتها من الرئيسية.');
  }
  if (/ملخص|متابعه|انجاز/.test(text)) return reply(`أنجزت ${tasks.length - remaining.length} من ${tasks.length} أنشطة اليوم. نعرض تأكيدات الجرعات المسجلة، لا تحققًا طبيًا.`, 'summary');
  if (/تركيز|ركز/.test(text)) return reply(remaining.length ? `لنركز على ${remaining[0].title}.` : 'لا توجد أنشطة متبقية اليوم.', 'focus');
  if (/مؤقت|وقت هادئ/.test(text)) return reply('اختر مدة ثم ابدأ. يمكنك إيقاف المؤقت متى شئت.', 'timer', ['وضع التركيز', 'اقرأ جدولي']);
  if (/بطاقات.*(مساعده|سريع)|صيدليه|مواصلات|تسوق|تسوق|طبيب/.test(text)) return reply('اختر بطاقة واعرضها لمن يساعدك.', 'help');
  if (/مرجعي|صورتي|بطاقاتي/.test(text)) return reply('هذه صورك وتسمياتك الصوتية المحفوظة محليًا.', 'references');
  if (/نسخ|احتياط|اعدادات/.test(text)) return reply('يمكنك تصدير نسخة محلية أو استعادتها من الإعدادات.', 'settings');
  if (/دوائي|ادويتي|ادويه|جرعات|مواعيد الدواء/.test(text)) {
    const medications = simple ? data.medications.slice(0, 1) : data.medications;
    return reply(medications.length ? medications.map(m => `${m.name}، ${m.dose}، المواعيد ${m.times.join(' و ')}.`).join('\n') : 'لا توجد أدوية محفوظة. يمكنك تسجيل الدواء حسب الوصفة.', 'none', ['سجل دواء', 'اقرأ جدولي']);
  }
  if (/جدول|عندي اليوم|لدي اليوم|روتين اليوم|مواعيد اليوم/.test(text)) {
    return reply(tasks.length ? (simple ? `اليوم: ${remaining.length} أنشطة متبقية. ${remaining[0] ? `الخطوة التالية: ${remaining[0].title}، ${remaining[0].time}.` : 'أكملت خطواتك.'}` : tasks.map(t => `${t.time}، ${t.title}، ${t.completed ? 'مكتمل' : 'لم يكتمل بعد'}.`).join('\n')) : 'جدول اليوم فارغ. أضف نشاطًا من جدولي.', 'schedule', ['ماذا أفعل الآن', 'اقرأ أدويتي', 'وضع التركيز']);
  }
  if (/ماذا افعل|ما الخطوه|خطوه تاليه|ساعدني|ارشاد/.test(text)) return reply(remaining[0] ? `خطوة واحدة الآن: ${remaining[0].title}. موعدها ${remaining[0].time}. خذ وقتك.` : 'خذ استراحة هادئة. يمكنك إضافة نشاط بسيط عندما تكون مستعدًا.', 'none', ['وضع التركيز', 'ابدأ مؤقت', 'اقرأ جدولي']);
  if (/مرحبا|اهلا|السلام|شكرا|تشجيع|تعبان|متعب|خائف|قلق/.test(text)) return reply(simple ? 'أنا معك. خذ وقتك. خطوة واحدة تكفي.' : `أهلًا${data.profile.name ? ` ${data.profile.name}` : ''}. كل خطوة لها قيمة. يمكنك الراحة ثم متابعة ما يناسبك.`, 'none', ['ماذا أفعل الآن', 'بطاقات المساعدة']);
  return reply('لم أفهم الأمر بعد. اختر خيارًا أو اكتب جملة قصيرة مثل: اقرأ جدولي.', 'none', defaultChips);
}
export function parseMedicationTimes(raw: string) { return normalizeArabic(raw).replace(/\s*:\s*/g, ':').split(/\s+/).filter(Boolean).map(t => /^\d:\d{2}$/.test(t) ? `0${t}` : t); }
export function draftMedication(draft: MedicationDraft): Omit<Medication, 'id' | 'taken'> | null { return draft.name.trim() && draft.dose.trim() && draft.times.length && draft.times.every(validTime) ? { name: draft.name.trim(), dose: draft.dose.trim(), times: [...new Set(draft.times)].sort() } : null; }
export const assistantExamples = ['اقرأ جدولي', 'ماذا عندي اليوم', 'سجل دواء', 'افتح الطوارئ', 'كرر', 'بدل الوضع إلى المكفوفين', 'اقرأ آخر ملاحظة'];
