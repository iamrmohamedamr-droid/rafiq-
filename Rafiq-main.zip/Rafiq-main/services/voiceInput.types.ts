export interface VoiceCallbacks { onText: (text: string) => void; onEnd: () => void; onError: (text: string) => void }
export interface VoiceSession { stop: () => void; cancel: () => void }
export const voiceUnavailable = 'الإدخال الصوتي العربي المحلي غير متاح هنا. استخدم النص أو الخيارات؛ لا نستخدم التعرف السحابي.';
