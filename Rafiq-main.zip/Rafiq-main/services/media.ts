import { Platform } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { persistMedia } from './mediaStorage';
export { persistMedia };
export async function pickPhoto(camera: boolean): Promise<string | null> {
  if (camera && Platform.OS !== 'web') { const p = await ImagePicker.requestCameraPermissionsAsync(); if (!p.granted) throw new Error('اسمح باستخدام الكاميرا من إعدادات الجهاز'); }
  if (!camera) { const p = await ImagePicker.requestMediaLibraryPermissionsAsync(); if (!p.granted) throw new Error('اسمح بالوصول إلى الصور'); }
  const result = camera && Platform.OS !== 'web' ? await ImagePicker.launchCameraAsync({ quality: 0.5 }) : await ImagePicker.launchImageLibraryAsync({ quality: 0.5 });
  if (result.canceled) return null;
  return persistMedia(result.assets[0].uri, 'jpg');
}
