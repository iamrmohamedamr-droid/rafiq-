import { today, type AppData } from './storage';
import { backupLimit, parseBackup } from './backupValidation';
import { portableMedia, materializeMedia, disposeMedia, exportFile, pickBackupFile } from './backupFiles';
export async function exportBackup(data: AppData) {
  const notes = await Promise.all(data.notes.map(async n => ({ ...n, uri: n.uri ? await portableMedia(n.uri, n.type === 'audio' ? 'audio' : 'image') : undefined })));
  const references = await Promise.all(data.references.map(async r => ({ ...r, photoUri: await portableMedia(r.photoUri, 'image'), audioUri: r.audioUri ? await portableMedia(r.audioUri, 'audio') : undefined })));
  const raw = JSON.stringify({ format: 'rafiq-local-backup', version: 2, createdAt: new Date().toISOString(), data: { ...data, notes, references } });
  if (raw.length > backupLimit) throw new Error('النسخة مع الوسائط أكبر من ٣٢ ميغابايت. لم يتم تصديرها.');
  parseBackup(raw); return exportFile(raw, `rafiq-backup-${today()}.json`);
}
export async function readBackup() { const raw = await pickBackupFile(); return raw === null ? null : parseBackup(raw); }
export async function prepareRestore(portable: AppData) {
  const created: string[] = [];
  const materialize = async (uri: string) => { const result = await materializeMedia(uri); if (result !== uri) created.push(result); return result; };
  try {
    const notes = []; for (const note of portable.notes) notes.push({ ...note, uri: note.uri ? await materialize(note.uri) : undefined });
    const references = []; for (const card of portable.references) references.push({ ...card, photoUri: await materialize(card.photoUri), audioUri: card.audioUri ? await materialize(card.audioUri) : undefined });
    return { data: { ...portable, notes, references }, rollback: () => disposeMedia(created) };
  } catch (error) { await disposeMedia(created); throw error; }
}
