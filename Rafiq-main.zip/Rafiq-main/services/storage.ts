import AsyncStorage from '@react-native-async-storage/async-storage';
import { phraseSeed, type Mode, type IconName } from '@/constants/config';
export interface Task { id: string; title: string; time: string; period: 'morning' | 'afternoon' | 'evening'; completed: boolean; day: string }
export interface Medication { id: string; name: string; dose: string; times: string[]; taken: string[] }
export interface Note { id: string; title: string; text: string; type: 'text' | 'audio' | 'photo'; uri?: string; created: string }
export interface Phrase { id: string; text: string; category: string; icon: IconName }
export interface Profile { name: string; blood: string; medical: string; contactName: string; contactPhone: string; communication: string; needs: string }
export interface ReferenceCard { id: string; label: string; photoUri: string; audioUri?: string; created: string }
export interface DoseRecord { id: string; medicationId: string; name: string; dose: string; day: string; time: string; confirmed: boolean }
export interface AppData { mode: Mode | null; tasks: Task[]; medications: Medication[]; notes: Note[]; phrases: Phrase[]; references: ReferenceCard[]; medicationHistory: DoseRecord[]; profile: Profile; preferences: { fontScale: number; contrast: boolean; dark: boolean; reducedMotion: boolean; reminders: boolean; timerChime: boolean; timerMinutes: number } }
const key = 'rafiq.local.v1';
export function today() { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; }
export function uid() { return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`; }
export function initialData(): AppData { return { mode: null, tasks: [], medications: [], notes: [], phrases: phraseSeed, references: [], medicationHistory: [], profile: { name: '', blood: '', medical: '', contactName: '', contactPhone: '', communication: 'تحدث معي بوضوح وبهدوء', needs: '' }, preferences: { fontScale: 1, contrast: false, dark: false, reducedMotion: false, reminders: false, timerChime: false, timerMinutes: 5 } }; }
export async function loadData(): Promise<AppData> {
  const raw = await AsyncStorage.getItem(key);
  if (!raw) return initialData();
  const stored = JSON.parse(raw); const defaults = initialData();
  return { ...defaults, ...stored, references: Array.isArray(stored.references) ? stored.references : [], medicationHistory: Array.isArray(stored.medicationHistory) ? stored.medicationHistory : [], preferences: { ...defaults.preferences, ...stored.preferences }, profile: { ...defaults.profile, ...stored.profile } };
}
export async function saveData(data: AppData) { await AsyncStorage.setItem(key, JSON.stringify(data)); }
export function validTime(value: string) { return /^([01]\d|2[0-3]):[0-5]\d$/.test(value); }
export function periodFor(time: string): Task['period'] { const hour = Number(time.split(':')[0]); return hour < 12 ? 'morning' : hour < 17 ? 'afternoon' : 'evening'; }
