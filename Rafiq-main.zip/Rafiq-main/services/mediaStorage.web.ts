/** Browser-only media persistence; native file-system code is never bundled here. */
export async function persistMedia(uri: string, _extension: string): Promise<string> {
  if (uri.startsWith('data:')) return uri;
  if (!uri.startsWith('blob:')) throw new Error('لا يمكن حفظ وسائط من الإنترنت. اختر ملفًا محليًا.');
  const response = await fetch(uri);
  if (!response.ok) throw new Error('تعذّر قراءة الوسائط المحلية');
  const blob = await response.blob();
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') resolve(reader.result);
      else reject(new Error('تعذّر حفظ الوسائط محليًا'));
    };
    reader.onerror = () => reject(new Error('تعذّر قراءة الوسائط المحلية'));
    reader.readAsDataURL(blob);
  });
}
