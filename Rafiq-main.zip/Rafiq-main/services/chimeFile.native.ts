import * as FileSystem from 'expo-file-system';
import { uid } from './storage';
export async function prepareChime(dataUri: string) { if (!FileSystem.cacheDirectory) throw new Error('الصوت المحلي غير متاح.'); const uri = `${FileSystem.cacheDirectory}rafiq-chime-${uid()}.wav`; await FileSystem.writeAsStringAsync(uri, dataUri.slice(dataUri.indexOf(',') + 1), { encoding: FileSystem.EncodingType.Base64 }); return { uri, cleanup: () => FileSystem.deleteAsync(uri, { idempotent: true }).catch(() => {}) }; }
