import * as FileSystem from 'expo-file-system';
import { uid } from './storage';
/** Expo SDK-compatible native document storage, isolated from the web bundle. */
export async function persistMedia(uri: string, extension: string): Promise<string> {
  if (!FileSystem.documentDirectory) throw new Error('التخزين المحلي غير متاح');
  const folder = `${FileSystem.documentDirectory}rafiq/`;
  await FileSystem.makeDirectoryAsync(folder, { intermediates: true });
  const safeExtension = extension.replace(/[^a-z0-9]/gi, '') || 'bin';
  const destination = `${folder}${uid()}.${safeExtension}`;
  await FileSystem.copyAsync({ from: uri, to: destination });
  return destination;
}
