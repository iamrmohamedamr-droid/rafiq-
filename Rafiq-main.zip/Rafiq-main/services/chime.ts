import { Audio } from 'expo-av';
import { prepareChime } from './chimeFile';
function encodeBase64(bytes: Uint8Array) { const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'; let result = ''; for (let i = 0; i < bytes.length; i += 3) { const n = (bytes[i] << 16) | ((bytes[i + 1] || 0) << 8) | (bytes[i + 2] || 0); result += alphabet[(n >>> 18) & 63] + alphabet[(n >>> 12) & 63] + (i + 1 < bytes.length ? alphabet[(n >>> 6) & 63] : '=') + (i + 2 < bytes.length ? alphabet[n & 63] : '='); } return result; }
/** A gentle 440 Hz WAV generated entirely on device; no remote sound asset. */
export function chimeUri() {
  const rate = 16000; const samples = 6400; const bytes = new Uint8Array(44 + samples * 2); const view = new DataView(bytes.buffer);
  const write = (offset: number, text: string) => { for (let i = 0; i < text.length; i++) bytes[offset + i] = text.charCodeAt(i); };
  write(0, 'RIFF'); view.setUint32(4, 36 + samples * 2, true); write(8, 'WAVE'); write(12, 'fmt '); view.setUint32(16, 16, true); view.setUint16(20, 1, true); view.setUint16(22, 1, true); view.setUint32(24, rate, true); view.setUint32(28, rate * 2, true); view.setUint16(32, 2, true); view.setUint16(34, 16, true); write(36, 'data'); view.setUint32(40, samples * 2, true);
  for (let i = 0; i < samples; i++) { const envelope = Math.min(1, i / 320) * Math.pow(1 - i / samples, 2); view.setInt16(44 + i * 2, Math.round(Math.sin(2 * Math.PI * 440 * i / rate) * 4500 * envelope), true); }
  return `data:audio/wav;base64,${encodeBase64(bytes)}`;
}
export async function playChime(): Promise<() => void> {
  const file = await prepareChime(chimeUri());
  try {
    const { sound } = await Audio.Sound.createAsync({ uri: file.uri }); let active = true;
    const cleanup = () => { if (!active) return; active = false; void sound.unloadAsync().finally(() => file.cleanup()); };
    sound.setOnPlaybackStatusUpdate(status => { if (status.isLoaded && status.didJustFinish) cleanup(); });
    try { await sound.playAsync(); } catch (error) { cleanup(); throw error; }
    return cleanup;
  } catch (error) { await file.cleanup(); throw error; }
}
