import { today, uid, type AppData, type DoseRecord } from './storage';
/** Snapshots are made only for days actually observed on this device. */
export function captureDoses(data: AppData, day = today()): DoseRecord[] {
  const records = [...data.medicationHistory];
  for (const med of data.medications) {
    for (const time of med.times) {
      const index = records.findIndex(r => r.medicationId === med.id && r.day === day && r.time === time);
      const confirmed = med.taken.includes(`${day}:${time}`);
      if (index < 0) records.push({ id: uid(), medicationId: med.id, name: med.name, dose: med.dose, day, time, confirmed });
      else if (records[index].confirmed !== confirmed) records[index] = { ...records[index], confirmed };
    }
    // Preserve older explicit confirmations when migrating earlier local records.
    for (const key of med.taken) {
      const match = /^(\d{4}-\d{2}-\d{2}):(\d{2}:\d{2})$/.exec(key);
      if (match && !records.some(r => r.medicationId === med.id && r.day === match[1] && r.time === match[2])) records.push({ id: uid(), medicationId: med.id, name: med.name, dose: med.dose, day: match[1], time: match[2], confirmed: true });
    }
  }
  return records;
}
export function dailyProgress(data: AppData, day = today()) {
  const tasks = data.tasks.filter(t => t.day === day).sort((a, b) => a.time.localeCompare(b.time));
  const completed = tasks.filter(t => t.completed).length;
  const doses = data.medicationHistory.filter(r => r.day === day);
  const confirmed = doses.filter(r => r.confirmed).length;
  return { tasks, completed, percent: tasks.length ? Math.round(completed / tasks.length * 100) : 0, doses, confirmed };
}
export function recentDays(count = 7) {
  return Array.from({ length: count }, (_, index) => { const d = new Date(); d.setDate(d.getDate() - index); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; });
}
