import { Platform } from 'react-native';
import * as Speech from 'expo-speech';
let lastSpeech = 'مرحبًا بك في رفيقك';
let sequence = 0;
export async function speakArabic(text: string): Promise<boolean> {
  lastSpeech = text;
  const current = ++sequence;
  try {
    await Speech.stop();
    const voices = await Speech.getAvailableVoicesAsync();
    // Android exposes both network and local voice identifiers. Only explicitly
    // local identifiers are allowed. Unverifiable voices remain a text fallback.
    const voice = voices.find(v => v.language.toLowerCase().startsWith('ar') && (Platform.OS === 'ios' || /(?:^|[-_])local$/i.test(v.identifier)));
    if (current !== sequence) return true;
    if (!voice) return false;
    Speech.speak(text, { language: 'ar', voice: voice.identifier, rate: 0.85 });
    return true;
  } catch { return false; }
}
export function repeatSpeech() { return speakArabic(lastSpeech); }
export function stopSpeech() { return Speech.stop(); }
