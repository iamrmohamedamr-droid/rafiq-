import { Platform } from 'react-native';
import type { AppData } from './storage';
import { today } from './storage';
export async function enableReminders(): Promise<boolean> {
  if (Platform.OS === 'web') return false;
  try {
    const Notifications = await import('expo-notifications');
    if (Platform.OS === 'android') await Notifications.setNotificationChannelAsync('rafiq', { name: 'تذكيرات رفيقك', importance: Notifications.AndroidImportance.HIGH, vibrationPattern: [0, 300, 200, 300] });
    const permission = await Notifications.requestPermissionsAsync();
    return permission.granted;
  } catch { return false; }
}
export async function syncReminders(data: AppData): Promise<void> {
  if (Platform.OS === 'web') return;
  try {
    const Notifications = await import('expo-notifications');
    await Notifications.cancelAllScheduledNotificationsAsync();
    if (!data.preferences.reminders) return;
    for (const task of data.tasks.filter(t => !t.completed && t.day === today())) {
      const when = new Date(`${task.day}T${task.time}:00`);
      if (when.getTime() > Date.now()) await Notifications.scheduleNotificationAsync({ content: { title: 'حان وقت نشاطك', body: task.title, sound: 'default' }, trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: when, channelId: 'rafiq' } });
    }
    for (const medicine of data.medications) for (const time of medicine.times) {
      const [hour, minute] = time.split(':').map(Number);
      await Notifications.scheduleNotificationAsync({ content: { title: 'تذكير بالدواء', body: `${medicine.name}، ${medicine.dose}`, sound: 'default' }, trigger: { type: Notifications.SchedulableTriggerInputTypes.DAILY, hour, minute, channelId: 'rafiq' } });
    }
  } catch { /* Local data remains usable if notification scheduling is unsupported. */ }
}
