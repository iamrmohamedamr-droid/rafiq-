// TypeScript/non-platform fallback. Metro resolves .web.ts or .native.ts first.
export { persistMedia } from './mediaStorage.web';
