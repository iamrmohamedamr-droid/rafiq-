import { Platform } from 'react-native';
import { speakArabic as nativeSpeak, stopSpeech as nativeStop } from './speech';
let lastText = 'مرحبًا بك في رفيقك';
let sequence = 0;
/** Browser voices must be local; never silently select a network voice. */
export async function speakArabic(text: string): Promise<boolean> {
  lastText = text; const request = ++sequence;
  if (Platform.OS !== 'web') return nativeSpeak(text);
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return false;
  const synth = window.speechSynthesis;
  synth.cancel();
  let voices = synth.getVoices();
  if (!voices.length) {
    await new Promise<void>(resolve => {
      const finish = () => { clearTimeout(timer); synth.removeEventListener('voiceschanged', finish); resolve(); };
      const timer = setTimeout(finish, 1000);
      synth.addEventListener('voiceschanged', finish, { once: true });
    });
    voices = synth.getVoices();
  }
  if (request !== sequence) return true;
  const voice = voices.find(v => v.lang.toLowerCase().startsWith('ar') && v.localService);
  if (!voice) return false;
  try { const utterance = new SpeechSynthesisUtterance(text); utterance.lang = voice.lang; utterance.voice = voice; utterance.rate = 0.85; synth.speak(utterance); return true; } catch { return false; }
}
export function repeatSpeech() { return speakArabic(lastText); }
export function stopSpeech() { sequence += 1; if (Platform.OS === 'web' && typeof window !== 'undefined' && 'speechSynthesis' in window) window.speechSynthesis.cancel(); return nativeStop(); }
