import { backupLimit } from './backupValidation';
export async function portableMedia(uri: string, kind: 'image' | 'audio'): Promise<string> {
  if (uri.startsWith('data:')) return uri;
  if (!uri.startsWith('blob:')) throw new Error('وسائط غير محلية. لن يتم تنزيل أي محتوى من الإنترنت.');
  const response = await fetch(uri); const blob = await response.blob();
  if (blob.size > backupLimit) throw new Error('حجم الوسائط أكبر من حد النسخة.');
  return new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => { if (typeof reader.result !== 'string') { reject(new Error('تعذّر قراءة الوسائط')); return; } const value = reader.result; resolve(value.startsWith(`data:${kind}/`) ? value : value.replace(/^data:[^;,]*/, `data:${kind}/${kind === 'audio' ? 'webm' : 'jpeg'}`)); }; reader.onerror = () => reject(new Error('تعذّر قراءة الوسائط')); reader.readAsDataURL(blob); });
}
export async function materializeMedia(uri: string): Promise<string> { return uri; }
export async function disposeMedia(_uris: string[]) {}
export async function exportFile(raw: string, filename: string): Promise<string> {
  const url = URL.createObjectURL(new Blob([raw], { type: 'application/json;charset=utf-8' })); const link = document.createElement('a'); link.href = url; link.download = filename; document.body.appendChild(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 10000); return 'تم تجهيز ملف JSON للتنزيل. احتفظ به في مكان آمن.';
}
export async function pickBackupFile(): Promise<string | null> {
  return new Promise((resolve, reject) => {
    const input = document.createElement('input'); input.type = 'file'; input.accept = '.json,application/json'; input.style.display = 'none'; document.body.appendChild(input);
    let finished = false; let focusTimer: ReturnType<typeof setTimeout> | undefined;
    const cleanup = () => { input.remove(); window.removeEventListener('focus', onFocus); if (focusTimer) clearTimeout(focusTimer); };
    const finish = (value: string | null) => { if (finished) return; finished = true; cleanup(); resolve(value); };
    const onFocus = () => { focusTimer = setTimeout(() => { if (!input.files?.length) finish(null); }, 1500); };
    input.oncancel = () => finish(null);
    input.onchange = async () => { const file = input.files?.[0]; if (!file) { finish(null); return; } try { if (file.size > backupLimit) throw new Error('حجم النسخة أكبر من ٣٢ ميغابايت.'); const raw = await file.text(); finish(raw); } catch (error) { finished = true; cleanup(); reject(error); } };
    window.addEventListener('focus', onFocus); input.click();
  });
}
