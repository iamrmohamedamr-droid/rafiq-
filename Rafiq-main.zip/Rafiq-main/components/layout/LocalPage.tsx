import type { ReactNode } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useDesign } from '@/hooks/useDesign';
import { spacing } from '@/constants/theme';
interface LocalPageProps { children: ReactNode; scroll?: boolean }
/** The Expo Router system header reserves the top safe area on detail pages. */
export function LocalPage({ children, scroll = true }: LocalPageProps) { const { palette } = useDesign(); return <SafeAreaView edges={['bottom']} style={[styles.safe, { backgroundColor: palette.background }]}><KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.safe}>{scroll ? <ScrollView style={styles.safe} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>{children}</ScrollView> : <View style={styles.safe}>{children}</View>}</KeyboardAvoidingView></SafeAreaView>; }
const styles = StyleSheet.create({ safe: { flex: 1 }, content: { width: '100%', maxWidth: 960, alignSelf: 'center', padding: spacing.lg, gap: spacing.md, paddingBottom: spacing.xl } });
