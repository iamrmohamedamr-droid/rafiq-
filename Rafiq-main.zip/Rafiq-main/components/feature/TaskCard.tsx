import { memo } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import type { Task } from '@/services/storage';
import { useRafiq } from '@/hooks/useRafiq';
import { useDesign } from '@/hooks/useDesign';
import { useVoice } from '@/hooks/useVoice';
import { Label } from '@/components/ui/Primitives';
import { radius, spacing } from '@/constants/theme';
interface TaskCardProps { task: Task; onEdit?: () => void; step?: number }
export const TaskCard = memo(function TaskCard({ task, onEdit, step }: TaskCardProps) {
  const { toggleTask, data } = useRafiq(); const { palette, large } = useDesign(); const { speak } = useVoice();
  const label = `${task.title}، الساعة ${task.time}، ${task.completed ? 'مكتمل' : 'غير مكتمل'}`;
  return <View style={[styles.card, { backgroundColor: palette.surface, borderColor: palette.border, minHeight: large ? 112 : 92 }]}><Pressable accessibilityRole="checkbox" accessibilityLabel={label} accessibilityState={{ checked: task.completed }} onFocus={() => { if (data.mode === 'blind') void speak(label); }} onPress={() => { toggleTask(task.id); if (data.mode === 'blind') void speak(task.completed ? 'تم إلغاء الإكمال' : `أحسنت، تم إكمال ${task.title}`); }} style={({ pressed }) => [styles.action, { opacity: pressed ? 0.7 : 1 }]}><View style={[styles.check, { backgroundColor: task.completed ? palette.primary : palette.soft, borderColor: task.completed ? palette.primary : palette.border }]}>{task.completed ? <Ionicons name="checkmark" size={22} color={palette.background} /> : step ? <Label bold color={palette.primary}>{step}</Label> : <Ionicons name="ellipse-outline" size={22} color={palette.muted} />}</View><View style={styles.grow}><Label bold style={task.completed ? styles.done : null}>{task.title}</Label><View style={styles.time}><Ionicons name="time-outline" size={15} color={palette.muted} /><Label subtle size={14}>{task.time} · {task.completed ? 'مكتمل' : 'بانتظارك'}</Label></View></View></Pressable>{onEdit ? <Pressable accessibilityRole="button" accessibilityLabel={`تعديل ${task.title}`} onPress={onEdit} style={({ pressed }) => [styles.edit, { opacity: pressed ? 0.6 : 1 }]}><Ionicons name="create-outline" color={palette.muted} size={22} /></Pressable> : null}</View>;
});
const styles = StyleSheet.create({ card: { borderWidth: 1, borderRadius: radius.md, flexDirection: 'row-reverse', alignItems: 'center', paddingHorizontal: spacing.md, gap: spacing.sm }, action: { flex: 1, flexDirection: 'row-reverse', alignItems: 'center', gap: spacing.md, paddingVertical: spacing.md }, check: { width: 44, height: 44, borderWidth: 1, borderRadius: radius.sm, alignItems: 'center', justifyContent: 'center' }, grow: { flex: 1 }, time: { flexDirection: 'row-reverse', alignItems: 'center', gap: spacing.xs }, edit: { minWidth: 48, minHeight: 48, alignItems: 'center', justifyContent: 'center' }, done: { textDecorationLine: 'line-through', opacity: 0.6 } });
