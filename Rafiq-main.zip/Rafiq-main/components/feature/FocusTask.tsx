import { useRouter } from 'expo-router';
import { Pressable, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFocusTask } from '@/hooks/useFocusTask';
import { useDesign } from '@/hooks/useDesign';
import { useVoice } from '@/hooks/useVoice';
import { spacing, radius } from '@/constants/theme';
import { Button, Label } from '@/components/ui/Primitives';
import { LocalPage } from '@/components/layout/LocalPage';
export function FocusTask() { const { task, complete } = useFocusTask(); const { palette } = useDesign(); const { speak } = useVoice(); const router = useRouter(); return <LocalPage><View style={styles.focus}>{task ? <><Pressable accessibilityRole="button" accessibilityLabel={`النشاط الحالي: ${task.title}، ${task.time}. المس لسماع النشاط`} onPress={() => { void speak(`${task.title}. الموعد ${task.time}`); }} style={({ pressed }) => [styles.task, { backgroundColor: palette.primarySoft, opacity: pressed ? 0.8 : 1 }]}><Ionicons name="leaf-outline" size={48} color={palette.primary} /><Label subtle style={styles.center}>هذا النشاط فقط، الآن</Label><Label bold size={36} style={styles.center}>{task.title}</Label><Label size={22} style={styles.center}>الموعد · {task.time}</Label></Pressable><Button title="تم الإنجاز" icon="checkmark-circle-outline" onPress={complete} style={styles.complete} /></> : <View style={styles.task}><Ionicons name="checkmark-circle-outline" size={64} color={palette.primary} /><Label size={28} bold style={styles.center}>لا توجد خطوات متبقية</Label><Label style={styles.center}>أحسنت. خذ استراحة أو أضف نشاطًا من جدولك.</Label><Button title="العودة إلى جدولي" variant="soft" onPress={() => router.replace('/(tabs)/schedule')} /></View>}</View></LocalPage>; }
const styles = StyleSheet.create({ focus: { minHeight: 360, gap: spacing.xl, paddingVertical: spacing.xl }, task: { minHeight: 260, padding: spacing.xl, borderRadius: radius.lg, alignItems: 'center', justifyContent: 'center', gap: spacing.lg }, center: { textAlign: 'center' }, complete: { minHeight: 100 } });
