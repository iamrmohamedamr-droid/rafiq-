import { Linking, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useRafiq } from '@/hooks/useRafiq';
import { useDesign } from '@/hooks/useDesign';
import { modes } from '@/constants/config';
import { Button, Card, Label } from '@/components/ui/Primitives';
import { Sheet } from '@/components/ui/Sheet';
import { spacing } from '@/constants/theme';
interface EmergencyCardProps { visible: boolean; onClose: () => void; identity?: boolean }
export function EmergencyCard({ visible, onClose, identity = false }: EmergencyCardProps) {
  const { data, setNotice } = useRafiq(); const { palette } = useDesign(); const router = useRouter(); const p = data.profile;
  return <Sheet visible={visible} title={identity ? 'بطاقة التعريف والمساعدة' : 'معلومات الطوارئ'} onClose={onClose}><Card tint><View style={styles.heading}><Ionicons name={identity ? 'id-card-outline' : 'medical-outline'} color={identity ? palette.primary : palette.danger} size={36} /><View style={styles.grow}><Label size={26} bold>{p.name || 'لم يُضف الاسم بعد'}</Label><Label subtle>{modes.find(m => m.id === data.mode)?.title || 'رفيقك'}</Label></View></View><Label bold>طريقة التواصل المناسبة</Label><Label>{p.communication || 'غير محددة'}</Label><Label bold>أحتاج إلى</Label><Label>{p.needs || 'اسألني كيف يمكنك مساعدتي'}</Label></Card><Card><Label bold>فصيلة الدم</Label><Label size={22}>{p.blood || 'غير مسجلة'}</Label><Label bold>معلومات طبية مهمة</Label><Label>{p.medical || 'لم تُسجّل معلومات طبية'}</Label></Card><Card><Label bold>جهة اتصال للطوارئ</Label><Label>{p.contactName || 'لم تُضف جهة اتصال'}</Label><Label>{p.contactPhone || 'لا يوجد رقم مسجل'}</Label>{p.contactPhone ? <Button title="اتصل بجهة الطوارئ" icon="call-outline" variant="danger" onPress={() => { const phone = p.contactPhone.replace(/[^+\d]/g, ''); if (!phone) { setNotice('رقم الاتصال غير صالح'); return; } Linking.openURL(`tel:${phone}`).catch(() => setNotice('تعذّر فتح الاتصال على هذا الجهاز')); }} /> : null}</Card><Button title="تعديل معلوماتي" variant="outline" icon="create-outline" onPress={() => { onClose(); router.push('/(tabs)/settings'); }} /><Label subtle size={14}>هذه البطاقة متاحة دون إنترنت. الاتصال الهاتفي يتطلب شبكة اتصال. لا تتصل خدمات الطوارئ تلقائيًا.</Label></Sheet>;
}
const styles = StyleSheet.create({ heading: { flexDirection: 'row-reverse', alignItems: 'center', gap: spacing.md }, grow: { flex: 1 } });
