import { FlatList, Pressable, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { modes } from '@/constants/config';
import { radius, spacing } from '@/constants/theme';
import { useRafiq } from '@/hooks/useRafiq';
import { useDesign } from '@/hooks/useDesign';
import { useVoice } from '@/hooks/useVoice';
import { Card, Label } from '@/components/ui/Primitives';
import { Sheet } from '@/components/ui/Sheet';
interface ModeSwitcherProps { visible: boolean; onClose: () => void; onboarding?: boolean }
export function ModeSwitcher({ visible, onClose, onboarding = false }: ModeSwitcherProps) {
  const { data, setMode } = useRafiq(); const { palette } = useDesign(); const { speak } = useVoice();
  return <Sheet visible={visible} title={onboarding ? 'أهلًا بك في رفيقك' : 'اختر الوضع الأنسب لك'} onClose={onClose} locked={onboarding}><Card tint><View style={styles.intro}><Ionicons name="leaf-outline" size={36} color={palette.primary} /><Label bold size={22}>كل يوم، خطوة أسهل</Label></View><Label subtle>اختر طريقة الاستخدام المناسبة لك. يمكنك تغييرها في أي وقت. بياناتك تبقى على جهازك.</Label></Card><FlatList scrollEnabled={false} data={modes} keyExtractor={m => m.id} renderItem={({ item }) => <Pressable accessibilityRole="radio" accessibilityState={{ selected: data.mode === item.id }} accessibilityLabel={`${item.title}. ${item.description}`} onFocus={() => { void speak(`${item.title}. ${item.description}`); }} onPress={() => { setMode(item.id); onClose(); }} style={({ pressed }) => [styles.mode, { backgroundColor: palette.surface, borderColor: data.mode === item.id ? palette.primary : palette.border, opacity: pressed ? 0.7 : 1 }]}><View style={[styles.icon, { backgroundColor: palette.primarySoft }]}><Ionicons name={item.icon} size={28} color={palette.primary} /></View><View style={styles.grow}><Label bold>{item.title}</Label><Label subtle size={14}>{item.description}</Label></View><Ionicons name={data.mode === item.id ? 'checkmark-circle' : 'chevron-back'} size={24} color={palette.primary} /></Pressable>} ItemSeparatorComponent={() => <View style={styles.separator} />} /><Label subtle size={14}>للصوت دون إنترنت، ثبّت صوتًا عربيًا في إعدادات جهازك. لا تُرسل بياناتك إلى أي خادم.</Label></Sheet>;
}
const styles = StyleSheet.create({ intro: { flexDirection: 'row-reverse', alignItems: 'center', gap: spacing.md }, mode: { flexDirection: 'row-reverse', alignItems: 'center', padding: spacing.md, borderWidth: 1, borderRadius: radius.md, gap: spacing.md, minHeight: 96 }, icon: { width: 52, height: 52, alignItems: 'center', justifyContent: 'center', borderRadius: radius.sm }, grow: { flex: 1 }, separator: { height: spacing.sm } });
